package capstone.cmsc495.ekganalyzer;

import com.google.gson.Gson;

class Device{
    String deviceId;
    String deviceStatus;
    String userId;
    Session session;
    private static Gson mapper = new Gson();

    // Account Constructor
//    public Device(String deviceId, String deviceStatus){}


    public Device(String deviceId,String userId, String deviceStatus){
        this.deviceId = deviceId;
        this.deviceStatus = deviceStatus;
    }


    public Device(String deviceId, String userId, String deviceStatus, Session devSession){
        this.deviceId=deviceId;
        this.deviceStatus=deviceStatus;
        this.session= devSession;
    }
    public String toJson(){
        return mapper.toJson(this);
    }
}