package capstone.cmsc495.ekganalyzer;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

//import com.amazonaws.amplify.generated.graphql.CreateUserMutation;
import com.amazonaws.amplify.generated.graphql.CreateAccountMutation;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobile.client.UserStateListener;
import com.amazonaws.mobile.client.results.SignUpResult;
import com.amazonaws.mobile.client.results.Tokens;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.appsync.AWSAppSyncClient;
import com.amazonaws.mobileconnectors.appsync.sigv4.CognitoUserPoolsAuthProvider;
import com.amazonaws.regions.Regions;
import com.apollographql.apollo.GraphQLCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;


import javax.annotation.Nonnull;


public class SignUpActivity extends AppCompatActivity {

    public static final String TAG = "SignUpActivity";
    EditText emailEditText;
    EditText passwordEditText;
    EditText sensorIDEditText;

    private CMSCApiClient appSyncApi;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        // Get API Client
        appSyncApi = new CMSCApiClient(this.getApplicationContext());


        emailEditText = findViewById(R.id.emailTextField);
        passwordEditText = findViewById(R.id.passwordTextField);
        sensorIDEditText = findViewById(R.id.sensorIDTextField);
    }// End onCreate Method

    private boolean textFieldsAreEmpty() {
        return emailEditText.getText().toString().equals("") ||
                passwordEditText.getText().toString().equals("") ||
                sensorIDEditText.getText().toString().equals("");
    }// End textFieldsAreEmpty() Method

    public void signUp(View view) {

        String email = emailEditText.getText().toString();
        String password = passwordEditText.getText().toString();
        String sensorID = sensorIDEditText.getText().toString();

        Map<String, String> attributes = new HashMap<>();
        attributes.put("custom:sensorID", sensorID);
        attributes.put("custom:userID", email);
        attributes.put("email", email);

        if (!textFieldsAreEmpty()) {
            AWSMobileClient.getInstance().signUp(email, password, attributes, null, new Callback<SignUpResult>() {
                @Override
                public void onResult(SignUpResult result) {

                    Intent intent;

                    if(!result.getConfirmationState()) {
                        intent = new Intent(SignUpActivity.this, CodeInputActivity.class);
                    } else {
                        intent = new Intent(SignUpActivity.this, LoginActivity.class);
                    }// End if

                    startActivity(intent);
                }// End method

                @Override
                public void onError(final Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Log.e(TAG, e.getMessage());
                            Toast.makeText(SignUpActivity.this, "Please try again!", Toast.LENGTH_SHORT).show();
                        }
                    });
                }// End method
            });// End closure

        } else {
            Toast.makeText(this, "Please fill out all 3 fields", Toast.LENGTH_SHORT).show();
        }// ENd if else
    }
}// End SignUpActivity class
