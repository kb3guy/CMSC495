package capstone.cmsc495.ekganalyzer;

import com.apollographql.apollo.api.Response;
import com.google.gson.Gson;

class Record{
    int frequency;
    String recordId;
    float[] beats;
    private static Gson mapper = new Gson();

    public Record(Response res){}
    public Record(int freq, String recId, float[] beats){}
}