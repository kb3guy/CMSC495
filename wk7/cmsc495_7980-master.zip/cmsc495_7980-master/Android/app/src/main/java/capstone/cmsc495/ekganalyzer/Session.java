package capstone.cmsc495.ekganalyzer;

class Session{
    Record record;
    String sessionId;
    String deviceid;
    String userId;


    /**
     *
     * @TODO Refactor Session obj
     *
     * */
    public Session(String sessionId, String deviceId, String userId){

    }
}