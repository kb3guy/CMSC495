package capstone.cmsc495.ekganalyzer;

import android.content.Context;
import android.util.Log;

import com.amazonaws.amplify.generated.graphql.*;
import com.amazonaws.amplify.generated.graphql.GetAccountQuery;
import com.amazonaws.amplify.generated.graphql.CreateAccountMutation;
import com.amazonaws.amplify.generated.graphql.GetDeviceQuery;
import com.amazonaws.amplify.generated.graphql.GetSessionQuery;
import com.amazonaws.amplify.generated.graphql.LoginMutation;
import com.amazonaws.amplify.generated.graphql.StartDeviceMutation;
import com.amazonaws.amplify.generated.graphql.StopDeviceMutation;
import com.amazonaws.amplify.generated.graphql.SubscribeToSessionSubscription;
import com.amazonaws.mobile.config.AWSConfiguration;
import com.amazonaws.mobileconnectors.appsync.AWSAppSyncClient;
import com.amazonaws.mobileconnectors.appsync.AppSyncSubscriptionCall;
import com.amazonaws.mobileconnectors.appsync.fetcher.AppSyncResponseFetchers;
import com.apollographql.apollo.GraphQLCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;
import com.google.gson.Gson;

import java.security.AccessControlContext;
import java.util.List;

import javax.annotation.Nonnull;


/***
 * @desc Client Wrapper of CMSC GraphQL API
 * @author Tim Patat
 */
public class CMSCApiClient{
    public enum  RequestContext {
        CREATE_ACCOUNT, GET_ACCOUNT, LOGIN, START_DEVICE, STOP_DEVICE, GET_DEVICE
        };
    private AWSAppSyncClient client;
    private AppSyncSubscriptionCall subscriptionWatcher;
    private  Gson mapper = new Gson();

    // Account Callbacks

    public  CMSCApiClient(final Context context){
        ClientFactory.init(context);
        client = ClientFactory.appSyncClient();
    }



    // User methods
    public void getAccount(String userId, GraphQLCall.Callback<GetAccountQuery.Data> getAccountCallback){
        client.query(GetAccountQuery.builder().userId(userId).build())
                .responseFetcher(AppSyncResponseFetchers.CACHE_AND_NETWORK)
                .enqueue(getAccountCallback);
    }

    public void login(String email, String password, GraphQLCall.Callback<LoginMutation.Data> loginCallback ){
        client.mutate(LoginMutation.builder().email(email).password(password).build()).enqueue(loginCallback);
    }


    public void createAcccount(String email, String password, String deviceId, GraphQLCall.Callback<CreateAccountMutation.Data> createAccountCallback ){
        client.mutate(CreateAccountMutation.builder().email(email).password(password).deviceId(deviceId).build()).enqueue(createAccountCallback);
    }

    public Account mapAccount(Response response, RequestContext req) {
        Account reqResponse=null;
        String archiveId="";
        String deviceId="";
        String deviceStatus="";
        String userId="";
        String email="";

        switch(req){
            case CREATE_ACCOUNT:
                    @Nonnull Response<CreateAccountMutation.Data> createRes= (Response<CreateAccountMutation.Data>) response;
                    CreateAccountMutation.CreateAccount createData = createRes.data() != null ? createRes.data().createAccount() : null;
                    CreateAccountMutation.Device createDevice = createData!=null ? createData.device(): null;
                    CreateAccountMutation.Archive createArchive = createData != null ? createData.archive(): null;

                if (createRes.data() != null) {
                        if( createArchive!= null){
                            archiveId = createArchive.archiveId();
                        }


                        if(createDevice !=null){
                            deviceId = createDevice.deviceId();
                            deviceStatus = createDevice.deviceStatus();
                        }
                        userId = createData!=null ? createData.userId(): null;
                        email = createData!=null ? createData.email(): null;
                        reqResponse = new Account(archiveId, deviceId, deviceStatus, userId, email);
                    }
                    break;
                case LOGIN:
                    @Nonnull Response<LoginMutation.Data> loginRes= (Response<LoginMutation.Data>) response;
                    LoginMutation.Login loginData = loginRes.data() != null ? loginRes.data().login() : null;
                    LoginMutation.Device loginDevice = loginData !=null ? loginData.device() : null;
                    LoginMutation.Archive loginArchive = loginData !=null ? loginData.archive() : null;
                    if (loginRes.data() != null) {
                        if( loginArchive != null){
                            archiveId = loginArchive.archiveId();
                        }


                        if(loginDevice !=null){
                            deviceId = loginDevice.deviceId();
                            deviceStatus = loginDevice.deviceStatus();
                        }
                        userId = loginData !=null ? loginData.userId(): null;
                        email = loginData !=null ? loginData.email(): null;
                        reqResponse = new Account(archiveId, deviceId, deviceStatus, userId, email);
                    }
                    break;
                case GET_ACCOUNT:
                    @Nonnull Response<GetAccountQuery.Data> getRes= (Response<GetAccountQuery.Data>) response;
                    GetAccountQuery.GetAccount getData = getRes.data() !=null ? getRes.data().getAccount(): null;
                    GetAccountQuery.Device getDevice = getData!=null ? getData.device(): null;
                    GetAccountQuery.Archive getArchive = getData !=null ? getData.archive(): null;


                    if (getRes.data() != null) {
                        if(getArchive !=null){
                            archiveId = getArchive.archiveId();
                        }

                        if(getDevice!=null){
                            deviceId = getDevice.deviceId();
                            deviceStatus = getDevice.deviceStatus();
                        }

                        userId = getData !=null ? getData.userId(): null;
                        email = getData !=null ? getData.email(): null;
                        reqResponse = new Account(archiveId, deviceId, deviceStatus, userId, email);
                    }
                    break;
            default:
                    break;
        }

        if(reqResponse == null){
            throw new RuntimeException("Request Context Not Specified!");
        }
        return reqResponse;
    }
     // Archive methods
    public void getArchive(String userId, GraphQLCall.Callback<GetArchiveQuery.Data> callback){
        client.query(GetArchiveQuery.builder().userId(userId).build())
                .responseFetcher(AppSyncResponseFetchers.CACHE_AND_NETWORK)
                .enqueue(callback);
    }


    public Archive mapArchive(Response<GetArchiveQuery.Data> response){
        Archive reqResponse =null;
        GetArchiveQuery.GetArchive getData = response.data() !=null ? response.data().getArchive() : null;
//        if (getData!=null) {
//            String archiveId = getData.archiveId();
//            List<GetArchiveQuery.Record> records = getData.records();
//            String userId = getData.userID();
//
//
//            reqResponse= new Archive(archiveId, userId);
//        }


        return reqResponse;
    }

//    // Device methods
    public void startDevice(String deviceId, String userId, GraphQLCall.Callback<StartDeviceMutation.Data> callback){
        client.mutate(StartDeviceMutation.builder().userId(userId).deviceId(deviceId).build()).enqueue(callback);
    }
    public void stopDevice(String deviceId, String userId,GraphQLCall.Callback<StopDeviceMutation.Data> callback){
        client.mutate(StopDeviceMutation.builder().userId(userId).deviceId(deviceId).build()).enqueue(callback);
    }
    public void getDevice(String deviceId, GraphQLCall.Callback<GetDeviceQuery.Data> callback){
        client.query(GetDeviceQuery.builder().deviceId(deviceId).build()).enqueue(callback);
    }

    public Device mapDevice(Response response, RequestContext context){
        Device reqResponse= null;

        String deviceId=null ;
        String deviceStatus= null;
        String sessionId = null;
        String userId= null;
        Session deviceSession;


        switch(context){
            case START_DEVICE:
                    @Nonnull  Response<StartDeviceMutation.Data> startRes = (Response<StartDeviceMutation.Data>) response;
                    StartDeviceMutation.StartDevice startData = startRes.data() != null ? startRes.data().startDevice() : null;
                    StartDeviceMutation.Session startSession = startData !=null ? startData.session() : null;

                    if(startData !=null) {
                        deviceId = startData.deviceId();

                        sessionId = startSession != null ? startSession.sessionId() : null;
                        deviceStatus = startData.deviceStatus();
                        userId = startData.userId();
                        deviceSession = new Session(sessionId, deviceId, userId);

                        reqResponse = new Device(deviceId, deviceStatus, userId, deviceSession);
                    }
                    break;

            case STOP_DEVICE:
                Response<StopDeviceMutation.Data> stopRes = (Response<StopDeviceMutation.Data>) response;
                deviceId = stopRes.data().stopDevice().deviceId();
                deviceStatus= stopRes.data().stopDevice().deviceStatus();
                sessionId= stopRes.data().stopDevice().session().sessionId();
                userId = stopRes.data().stopDevice().userId();
                deviceSession = new Session(sessionId, deviceId, userId);

                reqResponse = new Device(deviceId, deviceStatus, userId, deviceSession);
                break;

            case GET_DEVICE:
                Response<GetDeviceQuery.Data> getRes = (Response<GetDeviceQuery.Data>) response;
                deviceId = getRes.data().getDevice().deviceId();
                deviceStatus= getRes.data().getDevice().deviceStatus();
                sessionId= getRes.data().getDevice().session().sessionId();
                userId = getRes.data().getDevice().userId();
                deviceSession = new Session(sessionId, deviceId, userId);

                reqResponse = new Device(deviceId, deviceStatus, userId, deviceSession);
                break;

            default:
                break;
        }

        if(reqResponse == null){
            throw new RuntimeException("Request Context Not Specified!");
        }
        return reqResponse;
    }
    // Record methods
    public void subscribeToSession(String userId, String sessionId, AppSyncSubscriptionCall.Callback callback){
        SubscribeToSessionSubscription subscription = SubscribeToSessionSubscription.builder().build();
        subscriptionWatcher = client.subscribe(subscription);
        subscriptionWatcher.execute(callback);
    }


//    // Session methods
    private void getSession(String deviceId, GraphQLCall.Callback<GetSessionQuery.Data> callback ){
        client.query(GetSessionQuery.builder().deviceId(deviceId).build()).enqueue(callback);
    }
}