package capstone.cmsc495.ekganalyzer;


import com.google.gson.Gson;

class Account{
    public Archive archive;
    public Device device;
    public Session session;
    public String email;
    public String userId;
    private static Gson mapper = new Gson();


    public Account (String archiveId, String deviceId, String deviceStatus, String userId, String email){
        archive = new Archive(archiveId, userId);
        device = new Device(deviceId, userId, deviceStatus);
        this.email = email;
        this.userId = userId;
    }

    public String toJson(){
        return mapper.toJson(this);
    }
}
