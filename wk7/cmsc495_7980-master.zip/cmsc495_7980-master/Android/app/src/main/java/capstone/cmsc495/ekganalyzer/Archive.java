package capstone.cmsc495.ekganalyzer;

import com.apollographql.apollo.api.Response;
import com.google.gson.Gson;

import java.util.List;

class Archive{
    String userId;
    String json;
    String archiveId;
    List<Record> records;

    private static Gson mapper = new Gson();

    public Archive(Response<Archive> res){
        userId= res.data().userId;
        archiveId = res.data().userId;
    }
    public Archive(String archiveId, String userId) {
        this.archiveId=archiveId;
        this.userId =userId;
    }

    public String toJson(){
        return mapper.toJson(this);
    }
}