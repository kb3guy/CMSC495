# cmsc495_7980
Project repository for our CMSC495 Capstone Project where we will be creating an interface to gather and analyze EKG data for diagnostic purposes.

Products we intend to integrate with to some degree:
https://www.amazon.com/gp/product/B0794ZTLK5/ref=oh_aui_detailpage_o00_s00?ie=UTF8&psc=1

Source for EKG data:
https://physionet.org/physiobank/database/ptbdb/

Trello board for issue and status tracking:
https://trello.com/b/b6uh1YDN/application
