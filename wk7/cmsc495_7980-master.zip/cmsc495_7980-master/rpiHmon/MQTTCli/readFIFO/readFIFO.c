/*
* readFIFO.c
* Andrew Young
* 12/2/2018
*
* Designed to read a FIFO file and spit out its contents as a JSON-formatted message
*/

#include <stdio.h>
#include <stdio_ext.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>


// getFifoMessages(pipeFile);
FILE *FIFOfile;

// Close the FIFO file
int closeFIFO(){
	fclose(FIFOfile);
	return 0;
}

// This function opens a FIFO file for reading.
int initFIFO(const char *filename){
	FIFOfile = fopen(filename, "r");

	// Check that we have opened the file
	if(__freadable(FIFOfile)){
		printf("Successfully opened file stream %s",filename);
		return 0;
	}else{
		// Failure! Unable to read file. Close file to clean up, then whine.
		closeFIFO();
		printf("File %s unable to be opened for reading.",filename);
	}
	return -1;
}

// Spit out all new lines in JSON format
char *getFIFOMessages(){
		

	    char *line = NULL;
	    size_t len = 0;
	    ssize_t read;
	   // FIFOfile = fopen("/etc/motd", "r");
	    if (FIFOfile == NULL)
		exit(1);
	    while ((read = getline(&line, &len, FIFOfile)) != -1) {
//		printf("%s", line);
		printf("{deviceID: 'myID', data:[{value: %s}]}\n",line);
	    }
	    if (ferror(FIFOfile)) {
		/* handle error */
	    }
	

}


int main(int argc, char **argv)
{
	// open up a test FIFO
	initFIFO("testFIFO");
	
	// print out everything that comes through it, formatted
//	while(1){
		getFIFOMessages();
//	}

	return 0;
}

