let AWS = require('aws-sdk');
let dynamo = new AWS.DynamoDB();

let crypto = require('crypto');
// let bcrypt = require('bcrypt');


function sha512(password, salt) {
    var hash = crypto.createHmac('sha512', salt);
    hash.update(password);

    let val = hash.digest('hex');
    return val;

};


exports.handler = async(event, context, callback) => {
    let email;
    let submittedPassword;
    let salt;
    let saltedPassword;
    if (event.arguments != null) {
        email = event.arguments.email;
        submittedPassword = event.arguments.password;
    }


    // Compare Salt to Stored Password
    var params = {
        TableName: process.env.ACCOUNT_TABLE,
        ProjectionExpression: "#email, userId, password, salt",
        FilterExpression: "#email=:email",
        ExpressionAttributeNames: {
            "#email": "email",
        },
        ExpressionAttributeValues: {
            ":email": { S: email }
        }
    };
    let response = await dynamo.scan(params).promise().then(data => {
        console.log(JSON.stringify(data));
        return data.Items[0];
    }).catch(err => {
        console.log("Dynamo Error:" + err);
        callback(err);
    });


    salt = response.salt.S;
    saltedPassword = response.password.S;

    // Compare salted password with submited; 
    let encryptSubmitted = sha512(submittedPassword, salt);


    if (encryptSubmitted === saltedPassword) {
        let rtnObj = {
            statusCode: 200,
            body: {
                email: response.email.S,
                userId: response.email.S
            }
        };

        callback(null, rtnObj);
    } else {
        callback(new Error("Invalid Username/Password"));
    }

};