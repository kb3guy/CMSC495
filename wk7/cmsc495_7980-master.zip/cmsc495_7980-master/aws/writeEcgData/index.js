let AWS = require('aws-sdk');
let dynamo = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
let iot = new AWS.IotData({ endpoint: process.env.ENDPOINT });

function sendDeviceError(sessionId, deviceId) {
    let payloadObj = {
        'status': 'fail',
        'session': sessionId
    };
    let mqttMessage = {
        topic: `response/${deviceId}`,
        payload: JSON.stringify(payloadObj),
        qos: 0,
    }
    await iot.publish(mqttMessage).promise().then(data => {}).catch(err => {
        console.warn("IOT DEVICE ERR: " + err);
        callback(err);
    });
}


exports.handler = async(event, context, callback) => {
    let deviceId = event.deviceId;
    let deviceData = event.deviceData;

    console.log("goet Event: " + JSON.stringify(event));

    if (deviceId == null || deviceData == null) {
        console.warn('Invalid request body!');
        callback(new Error('Invalid request body!'));
    }

    // Retrive Session 
    let sessionQuery = {
        "TableName": process.env.SESSION_TABLE,
        KeyConditionExpression: "#di = :device",
        ExpressionAttributeNames: {
            "#di": "deviceId"
        },
        ExpressionAttributeValues: {
            ":device": { "S": deviceId }
        }
    };


    let sessionObj = await dynamo.query(sessionQuery).promise().then(data => {
        if (data.Items.length == 0) {
            console.warn("Session not found!");
            callback(new Error("Session Does not exist!"));
        } else {
            return data.Items[0];
        }
    }).catch(err => {
        console.log("DynamoDB Error(1): " + err);
        sendDeviceError(null, deviceId);
        callback(err);
    });




    // Update the session with the incoming data

    let sessionParams = {
        "TableName": process.env.SESSION_TABLE,
        "Key": {
            "deviceId": { "S": deviceId },
            "sessionId": { "S": sessionObj.sessionId.S }
        },
        "UpdateExpression": "set data = :val1",
        "ExpressionAttributeValues": {
            ":val1": { "L": deviceData },
        },
        "ReturnValues": "ALL_NEW"
    };


    console.log(sessionParams)

    sessionResult = await dynamo.updateItem(sessionParams).promise().then(data => {
        return data.Attributes;
    }).catch(err => {
        console.log('DynamoDb Error (2): ' + err);
        sendDeviceError(sessionObj.sessionId.S, deviceId);
        callback(err);
    });

    if (sessionResult != null) {
        let payloadObj = {
            'status': 'success',
            'session': sessionResult.sessionId.S
        };
        let mqttMessage = {
            topic: `response/${deviceId}`,
            payload: JSON.stringify(payloadObj),
            qos: 0,
        }
        await iot.publish(mqttMessage).promise().then(data => {
            console.log("IOT DEVICE Response :" + JSON.stringify(data));
            let callbackObj = {
                statusCode: 200,
                body: {
                    session: {
                        sessionId: sessionResult.sessionId.S,
                        deviceId: sessionResult.deviceId.S,
                        userId: sessionResult.userId.S,
                        sessionStatus: sessionResult.sessionStatus.S,
                        data: deviceData
                    }
                }
            };

            console.log("Returning: " + JSON.stringify(callbackObj));
            callback(null, callbackObj);
        }).catch(err => {
            console.warn("IOT DEVICE ERR: " + err);
            callback(err);
        });
    }

}


// Return success Message 


let deviceData = {
    "deviceId": "1234",
    "data": [{ 'value': 12.2 }, { 'value': 12.6 }, { 'value': 12.5 }, { 'value': 12.3 }]
};