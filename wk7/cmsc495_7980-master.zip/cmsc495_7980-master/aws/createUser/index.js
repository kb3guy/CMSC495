// let AWS = require('aws-sdk');
import { DynamoDB } from 'aws-sdk'
let dynamodb = new DynamoDB({ apiVersion: '2012-08-10' });
let uuid = require('uuid');
let crypto = require('crypto');


function getRandomString(length) {
    return crypto.randomBytes(Math.ceil(length / 2))
        .toString('hex')
        .slice(0, length);
}


function sha512(password, salt) {
    var hash = crypto.createHmac('sha512', salt);
    hash.update(password);

    let val = hash.digest('hex');
    return val;

};
async function handler(event, context, callback) {
    // User Account Vals 
    let email = event.arguments.email;
    let pass = event.arguments.password;
    let salt = getRandomString(16);
    let saltedPass = sha512(pass, salt);


    // Device Vals 
    let deviceId = event.arguments.deviceId;


    // Get Device Data

    let deviceParams = {
        "TableName": process.env.DEVICE_TABLE,
        "Key": {
            "serialNumber": { "S": deviceId }
        }
    };
    let device = await dynamodb.getItem(deviceParams).promise().then(data => {
        if (data != null) {
            return data.Item;
        } else {
            console.log("Device (" + deviceId + ") could not be found!");
            callback(new Error("No Device Could be Found!"));
        }
    }).catch(err => {
        console.log(err);
        callback(err);
    });

    // Create user in Dynamo
    let userId = uuid.v4();
    let userParams = {
        "TableName": process.env.USER_TABLE,
        "Item": {
            "userId": userId,
            "email": email,
            "password": saltedPass,
            "salt": salt
        }
    }

    let user = await dynamodb.putItem(userParams).promise().then(data => {
        if (data != null) {
            return data.Item;
        } else {
            console.log("Could not create User: " + email);
            callback(new Error("Could not create User!"));
        }
    }).catch(err => {
        console.log("Dynamo Put Item Error: " + err);
        callback(err);
    });

    // Assign to provided device
    let deviceUpdateParams = {
        TableName: process.env.DEVICE_TABLE,
        ExpressionAttributeNames: {
            "#u": "userId",
        },
        ExpressionAttributeValues: {
            ":val": {
                S: userId
            }
        },
        Key: {
            'deviceId': { "S": device.deviceId }
        },
        UpdateExpression: "SET #u = :val",
        ReturnValues: 'ALL_NEW'
    };

    dynamodb.updateItem(deviceUpdateParams).promise(data => {}).catch(err => {
        console.log('Dynamo Update Error: ' + err);
        callback(err);
    });
    // Create and link archive 
    let archiveId = uuid.v4();
    let archiveParams = {
        "TableName": process.env.ARCHIVE_TABLE,
        "Item": {
            "archiveId": archiveId,
            "userId": userId
        },
        "ReturnValues": "ALL_NEW"
    }

    let archive = await dynamodb.putItem(archiveParams).promise().then(data => {
        if (data != null) {
            return data.Item;
        } else {
            console.log("Could not create Archive: " + archiveId);
            callback(new Error("Could not create Archive!"));
        }
    }).catch(err => {
        console.log("Dynamo Put Item Error: " + err);
        callback(err);
    });
}