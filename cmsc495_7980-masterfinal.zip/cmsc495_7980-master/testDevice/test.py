'''
    Method to test streaming data on client 
    @author Tim Patat
'''
import boto3
import json
import sys
import os
import time
import random
import datetime
from AWSIoTPythonSDK.MQTTLib import AWSIoTMQTTClient
from AWSIoTPythonSDK.exception.AWSIoTExceptions import connectTimeoutException
DEVICE_ID="1212"
client  = AWSIoTMQTTClient('')
client.configureEndpoint('acxaeaeac84n1-ats.iot.us-east-1.amazonaws.com', 8883)
client.configureCredentials('./root-CA.crt', 'ECGMonitor.private.key', 'ECGMonitor.cert.pem')
client.configureAutoReconnectBackoffTime(1, 32, 20)
client.configureOfflinePublishQueueing(-1)  # Infinite offline Publish queueing
client.configureDrainingFrequency(2)  # Draining: 2 Hz
client.configureConnectDisconnectTimeout(10)  # 10 sec
client.configureMQTTOperationTimeout(5) # 5 sec
FREQUENCY=200


HEALTHY = './heart/healthy.csv'
DYS = './heart/Dysrhythmia.csv'
MYI = './heart/myi.csv'



def firstConnection(): 
    topic = "device/pair"
    qos = 1
    payload = {
        'serialNumber': DEVICE_ID, 
        'deviceStatus': 'active'
    }

    response = client.publish(topic,json.dumps(payload), qos)

    

    with open('token.json', 'w+') as file: 
        token= {
            'session': datetime.datetime.now().isoformat(),
            'deviceId': DEVICE_ID,
            'connected': True
        }
        json.dump(token, file)



def pushData(filePath= HEALTHY): 
    topic = "data/send"
    qos = 1
    payload = {
        'deviceId': DEVICE_ID,
        'data': []
    }

    print('Writing Data to IoT. (Ctrl+C to stop)')
    time.sleep(1)
    with open(filePath) as file: 
        try:
            while True: 
                #Clear data 
                payload['data'].clear()

                # Add dummy data
                for i in range(10): 
                    line=file.readline()
                    if(line == ""): 
                        file.seek(0)
                    data = line.split(',')[1]
                    payload['data'].append({'value': float(data)})
                

                client.connect()
                response = client.publish(topic, json.dumps(payload), qos)
                print('Data: '+json.dumps(payload))
                client.disconnect()
                time.sleep(1/20)


        except KeyboardInterrupt: 
            print('Exitting!')
            sys.exit(1)

        except connectTimeoutException: 
            print('Refreshing connection')
            time.sleep(1)
            pushData()

if __name__ == '__main__': 
    
    # Tokens indicate if a device has made a connection before
    hasToken = os.path.isfile('token.json')
    madeConnection = False
    
    if(hasToken): 
        with open('token.json') as file:
            token= json.load(file)
            if(token['deviceId']==DEVICE_ID): 
                madeConnection=True
            else:
                close(file)
                os.remove('./token.json')

    if not madeConnection: 
        firstConnection()


    if(len(sys.argv)>1):
        arg = sys.argv[1]

        if arg == "Dysrhythmia": 
            pushData(DYS)

        elif arg == "Heart_Attack": 
            pushData(MYI)
        else: 
            pushData()

    else: 
        pushData()

