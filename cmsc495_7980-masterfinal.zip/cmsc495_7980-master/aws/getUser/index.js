let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
exports.handler = async(event, context, callback) => {
    if (event.arguments != null) {
        let userId = event.arguments.userId;

        let params = {
            TableName: process.env.ACCOUNT_TABLE,
            Key: {
                "userId": { "S": userId },
                "email": { "S": userId }
            }
        };

        let user = await dynamodb.getItem(params).promise().then(res => {
            return res.Item;
        }).catch(err => {
            console.log('Dynamo Error(1): ' + JSON.stringify(err));
            callback(err);
        });


        let respObj = {
            statusCode: 200,
            body: {
                userId: user.userId ? user.userId.S : '',
                archiveId: user.archiveId ? user.archiveId.S : '',
                sessionId: user.sessionId ? user.sessionId.S : '',
                deviceId: user.deviceId ? user.deviceId.S : '',
                email: user.email ? user.email.S : ''
            }
        };


        callback(null, respObj);

    } else {
        console.log('No Arguments Provided!');
        callback(new Error('No Arguments Provided!'))
    }
};