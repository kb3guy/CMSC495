let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

function getBeats(beats) {
    let beatObj = [];
    for (let i = 0; i < beats.L.length; i++) {
        beatObj.push(JSON.parse(beats.L[i].S));
    }

    return beatObj;
}

function getValues(vals) {
    let valList = [];
    for (let i = 0; i < vals.L.length; i++) {
        valList.push(parseFloat(vals.L[i].N));
    }
    return valList;
}

exports.handler = async(event, context, callback) => {
    if (event.arguments != null) {
        let userId = event.arguments.userId;

        let query = {
            TableName: process.env.DEVICE_TABLE,
            KeyConditionExpression: "userId = :a",
            ExpressionAttributeValues: {
                ":a": { "S": userId },
            }
        };


        let device = await dynamodb.query(query).promise().then(res => {
            return res.Items[0];
        }).catch(err => {
            console.log('Dynamo Error(1): ' + JSON.stringify(err));
            callback(err);
        });

        if (device != null) {
            let deviceId = device.deviceId ? device.deviceId.S : '';
            let query = {
                TableName: process.env.SESSION_TABLE,
                KeyConditionExpression: "deviceId = :a",
                ExpressionAttributeValues: {
                    ":a": { "S": deviceId },
                }
            };


            let session = await dynamodb.query(query).promise().then(res => {
                return res.Items[0];
            }).catch(err => {
                console.log('Dynamo Error(1): ' + JSON.stringify(err));
                callback(err);
            });

            let respObj = {
                statusCode: 200,
                body: {
                    sessionId: session.sessionId ? session.sessionId.S : '',
                    userId: session.userId ? session.userId.S : '',
                    frequency: session.frequency ? parseFloat(session.frequency.N) : -1,
                    data: session.deviceData ? getValues(session.deviceData) : [],
                    status: session.sessionStatus ? session.sessionStatus.S : 'unknown',
                    beats: session.beats ? getBeats(session.beats) : []
                }
            };

            callback(null, respObj);
        }

    } else {
        console.log('No Arguments Provided!');
        callback(new Error('No Arguments Provided!'))
    }
}