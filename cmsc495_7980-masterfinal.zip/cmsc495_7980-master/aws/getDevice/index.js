let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

exports.handler = async(event, context, callback) => {
    if (event.arguments != null) {
        let userId = event.arguments.userId;

        let query = {
            TableName: process.env.DEVICE_TABLE,
            KeyConditionExpression: "userId = :a",
            ExpressionAttributeValues: {
                ":a": { "S": userId },
            }
        };


        let device = await dynamodb.query(query).promise().then(res => {
            return res.Items[0];
        }).catch(err => {
            console.log('Dynamo Error(1): ' + JSON.stringify(err));
            callback(err);
        });

        console.log(`Reciveved : ${JSON.stringify(device)}`);

        let respObj = {
            statusCode: 200,
            body: {
                sessionId: device.sessionId ? device.sessionId.S : '',
                deviceStatus: device.deviceStatus ? device.deviceStatus.S : '',
                userId: device.userId ? device.userId.S : '',
                deviceId: device.deviceId ? device.deviceId.S : ''
            }
        };

        callback(null, respObj);
    }
};