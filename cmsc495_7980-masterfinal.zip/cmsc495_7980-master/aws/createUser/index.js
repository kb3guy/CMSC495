let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
let uuid = require("uuid/v4");

exports.handler = async(event, context, callback) => {


    if (event.request != null) {
        let deviceId = event.request.userAttributes['custom:sensorID'];
        let userId = event.request.userAttributes['custom:userID'];
        let email = event.request.userAttributes['email'];
        // // Create user in Dynamo
        let sessionId = uuid();
        let userParams = {
            "TableName": process.env.USER_TABLE,
            "Item": {
                "userId": { S: userId },
                "deviceId": { S: deviceId },
                "sessionId": { S: sessionId },
                "email": { S: email }
            }
        };

        let user = await dynamodb.putItem(userParams).promise().then(data => {
            if (data != null) {
                return data.Item;
            } else {
                console.log("Could not create User: " + email);
                callback(new Error("Could not create User!"));
            }
        }).catch(err => {
            console.log("Dynamo Put Item Error: " + err);
            callback(err);
        });

        // Create session and device
        let sessionParams = {
            "TableName": process.env.SESSION_TABLE,
            "Item": {
                "deviceId": { S: deviceId },
                "sessionId": { S: sessionId },
                "status": { S: "inactive" }
            }
        };

        let deviceParams = {
            "TableName": process.env.DEVICE_TABLE,
            "Item": {
                "deviceId": { S: deviceId },
                "userId": { S: userId },
                "deviceStatus": { S: "inactive" }
            }
        };

        // Preform requests
        Promise.all([dynamodb.putItem(deviceParams).promise(), dynamodb.putItem(sessionParams).promise()]).then(data => {
            console.log(`Created Session and Device: ${JSON.stringify(data)}`);
            callback(null, JSON.stringify(data));
        }).catch(err => {
            console.log('Could not create device/session');
            callback(err);
        });
    } else {
        console.log("Request not detected");
        callback(new Error('Request not detected'));
    }
}