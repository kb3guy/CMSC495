let AWS = require('aws-sdk');
const fetch = require('node-fetch');
const URL = require('url');

const mutation = `mutation PushBeats($sessionId:String, $deviceId: String, $beats:[BeatInput]){
    addBeats(sessionId:$sessionId, deviceId: $deviceId, beats:$beats){
     sessionId
      beats{
        val
        stop
        start
        conditions{
          name
          conf
        }
      }
    }
  }`;


const archiveMutation = `mutation archiveIt($deviceId:String, $beats:[BeatInput]){
    archiveBeat(deviceId:$deviceId, beats:$beats){
      archiveId
      userId
      timeStamp
      beats{
        stop
        start
        val
        conditions{
          conf
          name
        }
      }
    }
  }`;





exports.handler = async(event, context, callback) => {
    console.log(`Received Event ${JSON.stringify(event)}`);
    if (event.arguments != null) {
        let deviceId = event.arguments.deviceId;
        let sessionId = event.arguments.sessionId;
        let beats = event.arguments.beats;

        // Parse Appsync endpoint uri
        const uri = URL.parse(process.env.API_ENDPOINT);


        // Trigger 'addBeats' subscription consumers
        const beatDetails = {
            deviceId: deviceId,
            sessionId: sessionId,
            beats: beats
        };

        const beat_post_body = {
            query: mutation,
            operationName: 'PushBeats',
            variables: beatDetails
        };

        console.log(`Posting: ${JSON.stringify(beat_post_body)}`);
        const beat_httpRequest = new AWS.HttpRequest(uri.href, process.env.REGION);
        beat_httpRequest.headers.host = uri.host;
        beat_httpRequest.headers['x-api-key'] = process.env.API_KEY;
        beat_httpRequest.headers['Content-Type'] = 'application/json';
        beat_httpRequest.method = 'POST';
        beat_httpRequest.body = JSON.stringify(beat_post_body);

        // Update the session with the incoming data
        const beat_options = {
            method: beat_httpRequest.method,
            body: beat_httpRequest.body,
            headers: beat_httpRequest.headers
        };

        fetch(uri.href, beat_options)
            .then(res => res.json())
            .then(json => {
                console.log(`JSON Response = ${JSON.stringify(json, null, 2)}`);
                callback(null, event);
            })
            .catch(err => {
                console.error(`FETCH ERROR: ${JSON.stringify(err, null, 2)}`);
                callback(err);
            });

        // Create Archive Creation Mutation request 
        const archiveInput = {
            deviceId: deviceId,
            beats: beats
        };

        const arc_post_body = {
            query: archiveMutation,
            operationName: 'archiveIt',
            variables: archiveInput
        };

        console.log(`Posting: ${JSON.stringify(arc_post_body)}`);

        const arc_httpRequest = new AWS.HttpRequest(uri.href, process.env.REGION);
        arc_httpRequest.headers.host = uri.host;
        arc_httpRequest.headers['x-api-key'] = process.env.API_KEY;
        arc_httpRequest.headers['Content-Type'] = 'application/json';
        arc_httpRequest.method = 'POST';
        arc_httpRequest.body = JSON.stringify(arc_post_body);

        // Update the session with the incoming data
        const arc_options = {
            method: arc_httpRequest.method,
            body: arc_httpRequest.body,
            headers: arc_httpRequest.headers
        };

        fetch(uri.href, arc_options)
            .then(res => res.json())
            .then(json => {
                console.log(`JSON Response = ${JSON.stringify(json, null, 2)}`);
            })
            .catch(err => {
                console.error(`FETCH ERROR: ${JSON.stringify(err, null, 2)}`);
            });

        let resp = {
            statusCode: 200,
            body: {}
        }

        callback(null, resp);
    } else {
        callback(new Error('No Arguments provided!'));
    }

}



let reqSample = {
    'deviceId': '1234',
    'sessionId': 'testSession',
    'beats': [{
        'start': 1,
        'stop': 2,
        'val': [1, 2, 3],
        'conditions': [{
            'name': 'something',
            'conf': 0.85
        }]
    }]
};