let AWS = require('aws-sdk');
let uuid = require('uuid/v4');
let dynamo = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

exports.handler = async(event, context, callback) => {
    console.log(`Receieved Event: ${JSON.stringify(event)}`);
    let deviceId = event.arguments.deviceId;
    let beats = event.arguments.beats;

    let dbBeats = [];

    for (let beat of beats) {
        dbBeats.push({ 'S': JSON.stringify(beat) });
    }
    console.log(dbBeats);

    var params = {
        TableName: process.env.DEVICE_TABLE,
        ProjectionExpression: "#d, userId",
        FilterExpression: "#d=:dev_id",
        ExpressionAttributeNames: {
            "#d": "deviceId",
        },
        ExpressionAttributeValues: {
            ":dev_id": { S: deviceId },
        }
    };

    const deviceResponse = await dynamo.scan(params).promise().then(data => {
        if (data.Items.length <= 0) {
            callback(new Error('Could not find device reference'));
        } else {
            return data.Items[0];
        }
    }).catch(err => {
        console.log(`Dynamo Error (1): ${JSON.stringify(err)}`);
        callback(err);
    });

    if (deviceResponse.userId) {
        let userId = deviceResponse.userId.S;
        let archiveId = uuid();
        let timeStamp = new Date(Date.now()).toISOString();
        var putParams = {
            TableName: process.env.ARCHIVE_TABLE,
            Item: {
                'userID': { S: userId },
                'archiveId': { S: archiveId },
                'beats': { L: dbBeats },
                'timeStamp': { S: timeStamp }
            }
        };

        await dynamo.putItem(putParams).promise().then(data => {
            let rtnObj = {
                status: 200,
                body: {
                    userId: userId,
                    archiveId: archiveId,
                    beats: beats,
                    timeStamp: timeStamp
                }
            };

            callback(null, rtnObj);
        }).catch(err => {
            console.log(`DynamoDb Error(2): ${JSON.stringify(err)}`);
            callback(err);
        });

    } else {
        console.log('No User Associated with provided device');
        callback(new Error('No User Associated with provided device'));
    }
}