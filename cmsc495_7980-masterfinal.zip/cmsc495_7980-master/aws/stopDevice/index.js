/**
 * @desc AppSync mutation Resolver. Sets the device and session state to inactive and notifies the hardware via IoT core.
 * @author Timothy Patat
 */

// import {DynamoDB, IotData} from 'aws-sdk';
let AWS = require('aws-sdk');
let dynamo = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
console.log("ENDPOINT" + process.env.ENDPOINT);
let iot = new AWS.IotData({ endpoint: process.env.ENDPOINT });


exports.handler = async(event, context, callback) => {
    let userId;
    let deviceId
    let deviceResult;
    let sessionResult;


    console.log("Recieved Request: " + JSON.stringify(event));
    if (event.arguments != null) {
        let args = event.arguments;
        userId = args != null ? args.userId : null;
        deviceId = args != null ? args.deviceId : null;
    }


    if (userId) {
        // Set device status to inactive
        let deviceParams = {
            "TableName": process.env.DEVICE_TABLE,
            "Key": {
                "userId": { "S": userId },
                "deviceId": { "S": deviceId },

            },
            "UpdateExpression": "set deviceStatus = :val1",
            "ExpressionAttributeValues": {
                ":val1": { "S": "inactive" },
            },
            "ReturnValues": "ALL_NEW"
        };


        console.log(deviceParams);

        deviceResult = await dynamo.updateItem(deviceParams).promise().then(data => {
            return data.Attributes
        }).catch(err => {
            console.log('DynamoDb Error (1): ' + err);
            callback(err);
        });

    }

    if (deviceId != null || deviceResult) {

        let sessionQuery = {
            "TableName": process.env.SESSION_TABLE,
            KeyConditionExpression: "#di = :device",
            ExpressionAttributeNames: {
                "#di": "deviceId"
            },
            ExpressionAttributeValues: {
                ":device": { "S": deviceId != null ? deviceId : deviceResult.deviceId.S }
            }
        };


        let sessionObj = await dynamo.query(sessionQuery).promise().then(data => {
            return data.Items[0];
        }).catch(err => {
            console.log("DynamoDB Error(2): " + err);
            callback(err);
        });



        if (sessionObj) {

            let sessionParams = {
                "TableName": process.env.SESSION_TABLE,
                "Key": {
                    "deviceId": { "S": deviceId != null ? deviceId : deviceResult.deviceId.S },
                    "sessionId": { "S": sessionObj.sessionId.S }
                },
                "UpdateExpression": "set sessionStatus = :val1",
                "ExpressionAttributeValues": {
                    ":val1": { "S": "inactive" },
                },
                "ReturnValues": "ALL_NEW"
            };


            console.log(sessionParams)

            sessionResult = await dynamo.updateItem(sessionParams).promise().then(data => {
                return data.Attributes;
            }).catch(err => {
                console.log('DynamoDb Error (3): ' + err);
                callback(err);
            });
        }

    }


    // Publish message to device subscribers
    if (deviceResult && sessionResult && userId) {

        let payloadObj = {
            'command': 'STOP',
            'user': userId,
        };
        let mqttMessage = {
            topic: `control/${deviceId!=null? deviceId : deviceResult.deviceId.S}`,
            payload: JSON.stringify(payloadObj),
            qos: 0,
        }

        console.log(mqttMessage);

        await iot.publish(mqttMessage).promise().then(data => {
            console.log("IOT DEVICE Response :" + JSON.stringify(data));
            let callbackObj = {
                statusCode: 200,
                body: {
                    deviceId: deviceResult.deviceId.S || deviceId,
                    deviceStatus: deviceResult.deviceStatus.S,
                    userId: deviceResult.userId.S,
                    session: {
                        sessionId: sessionResult.sessionId.S,
                        deviceId: sessionResult.deviceId.S,
                        userId: sessionResult.userId.S,
                        sessionStatus: sessionResult.sessionStatus.S
                    }
                }
            };

            console.log("Returning: " + JSON.stringify(callbackObj));
            callback(null, callbackObj);
        }).catch(err => {
            console.warn("IOT DEVICE ERR: " + err);
            callback(err);
        });


    }


}