/**
 * @desc Lambda triggered via IoT Core Rule. Persits an instance of the device and creates a session in Dynamo DB
 * @author Timothy Patat
 */

let AWS = require('aws-sdk');
const HTTP = require('http');
const URL = require('url');
let iot = new AWS.IotData({ endpoint: process.env.ENDPOINT });
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });
let uuid = require('uuid');



function reportError(err, deviceId) {
    let payloadObj = {
        'status': 'Error',
        'message': err.toString(),
    };

    let mqttMessage = {
        topic: `reponse/${deviceId}`,
        payload: JSON.stringify(payloadObj),
        qos: 0,
    };

    iot.publish(mqttMessage).promise().then(data => {
        console.log("IOT DEVICE Response :" + data);
    }).catch(err => {
        console.warn("IOT DEVICE ERR: " + err);
    });
}
exports.handler = async(event, context, callback) => {
    // Load the message passed into the Lambda function into a JSON object 
    var eventText = JSON.stringify(event, null, 2);

    // For Event Debugging
    console.log("Received event:", eventText);

    const deviceId = event.serialNumber ? event.serialNumber : null;
    const status = event.deviceStatus ? event.deviceStatus : null;

    if (status == null) {
        console.log('Cannot Create Deivce: No Status');
        reportError('No Status Provided', deviceId);
    } else if (deviceId == null) {
        console.log('Cannot Create Deivce: No Serial Number');
        reportError('Cannot Create Deivce: No Serial Number', 'unknown');
    } else {

        // Scan DB for device Data
        var params = {
            TableName: process.env.DEVICE_TABLE,
            ProjectionExpression: "#d, userId",
            FilterExpression: "#d=:dev_id",
            ExpressionAttributeNames: {
                "#d": "deviceId",
            },
            ExpressionAttributeValues: {
                ":dev_id": { S: deviceId },
            }
        };



        let device = await dynamodb.scan(params).promise().then(data => {
            if (data.Items.length <= 0) {
                reportError('Device has not been linked yet', deviceId);
                callback(new Error('Could not find device reference'));
            } else {
                return data.Items[0];
            }
        }).catch(err => {
            console.log(`DynamoDb error (1): ${JSON.stringify(err)}`);
            reportError(err.toString(), deviceId);
            callback(err);
        });


        let sessionId;
        let userId;
        if (device.sessionId != null) {
            sessionId = device.sessionId.S;
        } else {
            console.log('Could not find user id of device!');
            callback(new Error('Could not find user id of device!'));
        }


        if (device.userId != null) {
            userId = device.userId.S;

        } else {
            console.log('Could not find user id of device!');
            reportError('Could not find user id related to device', deviceId);
            callback(new Error('Could not find user id of device!'));
        }
        // Create Requests to update Session and Device to active
        let sessionParams = {
            "TableName": process.env.SESSION_TABLE,
            "Key": {
                "deviceId": { "S": deviceId },
                "sessionId": { "S": sessionId }
            },
            "UpdateExpression": "set status = :val1",
            "ExpressionAttributeValues": {
                ":val1": { "S": 'active' },
            },
            "ReturnValues": "ALL_NEW"
        };

        let deviceParams = {
            "TableName": process.env.DEVICE_TABLE,
            "Key": {
                "deviceId": { "S": deviceId },
                "userId": { "S": userId }
            },
            "UpdateExpression": "set deviceStatus = :val1",
            "ExpressionAttributeValues": {
                ":val1": { "S": 'active' },
            },
            "ReturnValues": "ALL_NEW"
        };



        let shouldAlertEC2 = false;
        await Promise.all([dynamodb.updateItem(sessionParams).promise(), dynamodb.updateItem(deviceParams).promise()])
            .then(responseList => {
                shouldAlertEC2 = true;
            }).catch(errs => {
                reportError('Could not update device/session status', deviceId);
                console.log('Error updatind device and session status');
                callback(errs);
            });


        // Alert the machine learning instance of the device pairing
        if (shouldAlertEC2) {
            let postBody = JSON.stringify({
                'sessionId': sessionId,
                'deviceId': deviceId
            });

            let postOptions = {
                host: process.env.EC2_HOST,
                port: process.env.EC2_PORT,
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }
            };


            let postRequest = HTTP.request(postOptions, res => {
                res.setEncoding('utf8');
                res.on('response', data => {
                    console.log('EC2 Instance Response: ' + JSON.stringify(data));
                });
                res.on('error', err => {
                    console.log('Error Recieved: ' + JSON.stringify(err));
                });
            });


            postRequest.write(postBody);
            postRequest.end();
        }

        // Publish to IoT for device response

        let payloadObj = {
            'command': 'CREATE',
            'deviceStatus': status,
        };

        let mqttMessage = {
            topic: `reponse/${deviceId}`,
            payload: JSON.stringify(payloadObj),
            qos: 0,
        };

        iot.publish(mqttMessage).promise().then(data => {
            console.log("IOT DEVICE Response :" + data);
        }).catch(err => {
            console.warn("IOT DEVICE ERR: " + err);
            callback(err);
        });

    }
};