let AWS = require('aws-sdk');
let dynamo = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

exports.handler = async(event, context, callback) => {
    console.log(`Receieved Event: ${JSON.stringify(event)}`);

    // let tempRtn= {
    //     statusCode: 200, 
    //     body: JSON.stringify(event.arguments)
    // };

    // return tempRtn;
    if (event.arguments != null) {
        let sessionId = event.arguments.sessionId;
        let beats = event.arguments.beats;
        let deviceId = event.arguments.deviceId;
        let dbBeats = [];

        for (let beat of beats) {
            dbBeats.push({ 'S': JSON.stringify(beat) });
        }
        console.log(dbBeats);

        let sessionParams = {
            "TableName": process.env.SESSION_TABLE,
            "Key": {
                "deviceId": { "S": deviceId },
                "sessionId": { "S": sessionId }
            },
            "UpdateExpression": "set beats = :val1",
            "ExpressionAttributeValues": {
                ":val1": { "L": dbBeats },
            },
            "ReturnValues": "ALL_NEW"
        };

        console.log(`Updating  Table: ${JSON.stringify(sessionParams)}`);

        const sessionResult = await dynamo.updateItem(sessionParams).promise().then(data => {
            if (data.Attributes == null) {
                console.warn("Could not find session!");
                callback(new Error("Session Not Found"));
            } else {
                return data.Attributes;
            }
        }).catch(err => {
            console.log('DynamoDb Error (1): ' + err);
            callback(err);
        });


        if (sessionResult != null) {
            let rtnObj = {
                statusCode: 200,
                body: {
                    sessionId: sessionId,
                    beats: beats
                }
            };

            callback(null, rtnObj);
        }
    } else {
        console.log('No event.arguments must be provided!');
        callback(new Error('No event.arguments must be provided!'));
    }
};


let reqSample = {
    'sessionId': 'testSession',
    'beats': [{
        'start': 1,
        'stop': 2,
        'val': [1, 2, 3],
        'conditions': [{
            'name': 'something',
            'conf': 0.85
        }]
    }]
};