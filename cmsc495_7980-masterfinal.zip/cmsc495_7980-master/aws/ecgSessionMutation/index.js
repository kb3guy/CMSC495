let AWS = require('aws-sdk');
let dynamo = new AWS.DynamoDB({ apiVersion: '2012-08-10' });

exports.handler = async(event, context, callback) => {
    console.log(`Event received: ${JSON.stringify(event)}`);
    let deviceId = event.arguments.deviceId;
    let sessionId = event.arguments.sessionId;
    let deviceData = event.arguments.data;
    let dataList = []

    for (let data of deviceData) {
        dataList.push({ "N": data.toString() });
    }
    let sessionParams = {
        "TableName": process.env.SESSION_TABLE,
        "Key": {
            "deviceId": { "S": deviceId },
            "sessionId": { "S": sessionId }
        },
        "UpdateExpression": "set deviceData = :val1",
        "ExpressionAttributeValues": {
            ":val1": { "L": dataList },
        },
        "ReturnValues": "ALL_NEW"
    };

    console.log(`Updating DB: ${sessionParams}`);
    let sessionResult = await dynamo.updateItem(sessionParams).promise().then(data => {
        if (data.Attributes == null) {
            console.warn("Could not find session!");
            callback(new Error("Session Not Found"));
        } else {
            return data.Attributes;
        }
    }).catch(err => {
        console.log('DynamoDb Error (1): ' + err);
        callback(err);
    });


    if (sessionResult != null) {
        let response = {
            statusCode: 200,
            body: {
                sessionId: sessionResult.sessionId ? sessionResult.sessionId.S : sessionId,
                deviceId: sessionResult.deviceId ? sessionResult.deviceId.S : deviceId,
                data: deviceData,
                sessionStatus: sessionResult.sessionStatus ? sessionResult.sessionStatus.S : 'unknown'
            }
        };

        callback(null, response);
    }
}