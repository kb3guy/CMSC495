let AWS = require('aws-sdk');
let dynamodb = new AWS.DynamoDB({ apiVersion: '2012-08-10' });


function getBeats(beats) {
    let beatObj = [];
    for (let i = 0; i < beats.L.length; i++) {
        beatObj.push(JSON.parse(beats.L[i].S));
    }

    return beatObj;
}
exports.handler = async(event, context, callback) => {
    if (event.arguments) {
        let userId = event.arguments.userId;

        let query = {
            TableName: process.env.ARCHIVE_TABLE,
            KeyConditionExpression: "userID = :a",
            ExpressionAttributeValues: {
                ":a": { "S": userId },
            }
        };


        let queryRes = await dynamodb.query(query).promise().then(data => {
            return data.Items;
        }).catch(err => {
            console.log(`DynamoDb error: ${JSON.stringify(err)}`);
            callback(err);
        });


        let responseBody = [];
        let beatObj;
        let timeStamp;
        let userIdVal;
        let archiveId;
        for (let i = 0; i < queryRes.length; i++) {
            beatObj = queryRes[i].beats ? getBeats(queryRes[i].beats) : '';
            timeStamp = queryRes[i].timeStamp ? queryRes[i].timeStamp.S : '';
            userIdVal = queryRes[i].userID ? queryRes[i].userID.S : '';
            archiveId = queryRes[i].archiveId ? queryRes[i].archiveId.S : '';

            responseBody.push({
                archiveId: archiveId,
                userId: userId,
                timeStamp: timeStamp,
                beats: beatObj
            });
        }


        const response = {
            statusCode: 200,
            body: responseBody
        }
        callback(null, response)


    } else {
        console.log("No Arguments provied!");
        callback(new Error("No Arguments provied!"));
    }
};