# cmsc495_7980
Project repository for our CMSC495 Capstone Project where we will be creating an interface to gather and analyze EKG data for diagnostic purposes utilizing machine learning.

Products we intend to integrate with to some degree:
https://www.amazon.com/gp/product/B0794ZTLK5/ref=oh_aui_detailpage_o00_s00?ie=UTF8&psc=1

Sources for EKG data:
https://physionet.org/physiobank/database/ptbdb/
https://www.physionet.org/physiobank/database/mitdb/

Setup instructions
See INSTALL.pdf file for setup instructions

