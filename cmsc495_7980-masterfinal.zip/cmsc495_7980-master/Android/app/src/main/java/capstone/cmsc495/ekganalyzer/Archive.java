package capstone.cmsc495.ekganalyzer;

import com.apollographql.apollo.api.Response;
import com.google.gson.Gson;

import java.util.List;

/**
 * Archive object for integration with AWS
 * @see CMSCApiClient
 */
class Archive{
    String userId;
    String archiveId;
    List<Beat> beats;
    String timeStamp;

    private static Gson mapper = new Gson();

    public Archive(String archiveId, String userId, List<Beat> beats, String timeStamp) {
        this.archiveId=archiveId;
        this.userId =userId;
        this.beats = beats;
        this.timeStamp = timeStamp;
    }

    public String getArchiveId() {
        return archiveId;
    }

    public List<Beat> getBeats() {
        return beats;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public String toJson(){
        return mapper.toJson(this);
    }
}