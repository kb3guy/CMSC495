package capstone.cmsc495.ekganalyzer;

import android.content.Context;
import android.util.Log;

import com.amazonaws.amplify.generated.graphql.*;
import com.amazonaws.amplify.generated.graphql.GetAccountQuery;
import com.amazonaws.amplify.generated.graphql.CreateAccountMutation;
import com.amazonaws.amplify.generated.graphql.GetDeviceQuery;
import com.amazonaws.amplify.generated.graphql.GetSessionQuery;
import com.amazonaws.amplify.generated.graphql.LoginMutation;
import com.amazonaws.amplify.generated.graphql.StartDeviceMutation;
import com.amazonaws.amplify.generated.graphql.StopDeviceMutation;
import com.amazonaws.amplify.generated.graphql.SubscribeToSessionSubscription;
import com.amazonaws.mobileconnectors.appsync.AWSAppSyncClient;
import com.amazonaws.mobileconnectors.appsync.AppSyncSubscriptionCall;
import com.amazonaws.mobileconnectors.appsync.fetcher.AppSyncResponseFetchers;
import com.apollographql.apollo.GraphQLCall;
import com.google.gson.Gson;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


/***
 * @desc Client Wrapper of CMSC GraphQL API
 * @author Tim Patat
 */
public class CMSCApiClient{
    private AWSAppSyncClient client;
    private AppSyncSubscriptionCall subscriptionWatcher;
    private  Gson mapper = new Gson();


    public  CMSCApiClient(final Context context){
        ClientFactory.init(context);
        client = ClientFactory.appSyncClient();
    }



    // User methods
    public void getAccount(String userId, GraphQLCall.Callback<GetAccountQuery.Data> getAccountCallback){
        client.query(GetAccountQuery.builder().userId(userId).build())
                .responseFetcher(AppSyncResponseFetchers.CACHE_AND_NETWORK)
                .enqueue(getAccountCallback);
    }

    public void login(String email, String password, GraphQLCall.Callback<LoginMutation.Data> loginCallback ){
        client.mutate(LoginMutation.builder().email(email).password(password).build()).enqueue(loginCallback);
    }


    public void createAcccount(String email, String password, String deviceId, GraphQLCall.Callback<CreateAccountMutation.Data> createAccountCallback ){
        client.mutate(CreateAccountMutation.builder().email(email).password(password).deviceId(deviceId).build()).enqueue(createAccountCallback);
    }

    public Account mapAccount(GetAccountQuery.Data data) {
        Account acc = null;
        if(data!=null){
            if(data.getAccount()!=null) {
                String deviceId=data.getAccount().deviceId() !=null ? data.getAccount().deviceId() : "";
                String sessionId=data.getAccount().sessionId() !=null ? data.getAccount().sessionId() : "";;
                String userId=data.getAccount().userId() !=null ? data.getAccount().userId() : "";;
                String email= data.getAccount().email() !=null ? data.getAccount().email() : "";;
                acc = new Account(deviceId,sessionId,userId, email );
            }
        } else {
            Log.w("Get Account", "Null User Response");
        }

        return acc;
    }

    public Account mapAccount(CreateAccountMutation.Data data) {
        Account acc = null;
        if(data!=null){
            if(data.createAccount()!=null) {
                String deviceId=data.createAccount().deviceId() !=null ? data.createAccount().deviceId() : "";
                String sessionId=data.createAccount().sessionId() !=null ? data.createAccount().sessionId() : "";;
                String userId=data.createAccount().userId() !=null ? data.createAccount().userId() : "";;
                String email= data.createAccount().email() !=null ? data.createAccount().email() : "";;
                acc = new Account(deviceId,sessionId,userId, email );
            }
        } else {
            Log.w("Create Account", "Null User Response");
        }

        return acc;
    }
    public Account mapAccount(LoginMutation.Data data) {
        Account acc = null;
        if(data!=null){
            if(data.login()!=null) {
                String deviceId=data.login().deviceId() !=null ? data.login().deviceId() : "";
                String sessionId=data.login().sessionId() !=null ? data.login().sessionId() : "";;
                String userId=data.login().userId() !=null ? data.login().userId() : "";;
                String email= data.login().email() !=null ? data.login().email() : "";;
                acc = new Account(deviceId,sessionId,userId, email );
            }
        } else {
            Log.w("Login", "Null User Response");
        }

        return acc;
    }

    // Archive methods
    public void getArchives(String userId, GraphQLCall.Callback<GetArchivesQuery.Data> callback){
        client.query(GetArchivesQuery.builder().userId(userId).build())
                .responseFetcher(AppSyncResponseFetchers.CACHE_AND_NETWORK)
                .enqueue(callback);
    }


    //    private List<Beat> getBeatList(List<GetSessionQuery.Beat> beats){}
    private List<Beat> arc_getBeatList(List<GetArchivesQuery.Beat> beats){
        List<Beat> rtn = new LinkedList<Beat>();
        if(beats !=null) {
            for (GetArchivesQuery.Beat beat : beats) {
                int start = beat.start() != null ? beat.start() : -1;
                int stop = beat.stop() != null ? beat.stop() : -1;
                List<Double> val = beat.val();


                List<GetArchivesQuery.Condition> conds = beat.conditions() != null ? beat.conditions() : new LinkedList<GetArchivesQuery.Condition>();
                List<Condition> conditionList = new LinkedList<>();

                for (GetArchivesQuery.Condition con : conds) {
                    String name = con.name();
                    Double conf = con.conf();
                    Condition condition = new Condition(name, conf);
                    conditionList.add(condition);
                }


                Beat b = new Beat(start, stop, val, conditionList);
                rtn.add(b);
            }
            return rtn;
        } else {
            Log.w("Get Archive", "Null beat list. Returning Null");
            return null;
        }
    }


    // Since the query returns a list of archives map to a list.
    public List<Archive> mapArchive(GetArchivesQuery.Data data){
        List<Archive> archives = new ArrayList<Archive>();

        if(data.getArchives()!=null) {
            for (GetArchivesQuery.GetArchive arc : data.getArchives()) {
                String userId = arc.userId();
                String archiveId= arc.archiveId();
                String timeStamp= arc.timeStamp();
                List<Beat> beats= this.arc_getBeatList(arc.beats()) ;

                Archive a = new Archive(userId, archiveId, beats, timeStamp);
                archives.add(a);
            }
        }

        return archives;
    }

    //    // Device methods
    public void startDevice(String deviceId, String userId, GraphQLCall.Callback<StartDeviceMutation.Data> callback){
        client.mutate(StartDeviceMutation.builder().userId(userId).deviceId(deviceId).build()).enqueue(callback);
    }
    public void stopDevice(String deviceId, String userId,GraphQLCall.Callback<StopDeviceMutation.Data> callback){
        client.mutate(StopDeviceMutation.builder().userId(userId).deviceId(deviceId).build()).enqueue(callback);
    }
    public void getDevice(String userId, GraphQLCall.Callback<GetDeviceQuery.Data> callback){
        client.query(GetDeviceQuery.builder().userId(userId).build()).enqueue(callback);
    }

    public Device mapDevice(StartDeviceMutation.Data data){
        Device d=null;

        if(data.startDevice()!=null){
            String deviceId = data.startDevice().deviceId();
            String userId = data.startDevice().userId();
            String status = data.startDevice().deviceStatus();
            String sessionId = data.startDevice().sessionId();

            d = new Device(deviceId, status, userId, sessionId);
        } else {
            Log.w("Get Device", "Null Device Response. Returning null");
        }

        return d;
    }
    public Device mapDevice(StopDeviceMutation.Data data){
        Device d=null;

        if(data.stopDevice()!=null){
            String deviceId = data.stopDevice().deviceId();
            String userId = data.stopDevice().userId();
            String status = data.stopDevice().deviceStatus();
            String sessionId = data.stopDevice().sessionId();

            d = new Device(deviceId, status, userId, sessionId);
        } else {
            Log.w("Get Device", "Null Device Response. Returning null");
        }

        return d;
    }
    public Device mapDevice(GetDeviceQuery.Data data){
        Device d=null;

        if(data.getDevice()!=null){
            String deviceId = data.getDevice().deviceId();
            String userId = data.getDevice().userId();
            String status = data.getDevice().deviceStatus();
            String sessionId = data.getDevice().sessionId();

            d = new Device(deviceId, status, userId, sessionId);
        } else {
            Log.w("Get Device", "Null Device Response. Returning null");
        }

        return d;
    }


    //    // Session methods
    private void getSession(String deviceId, GraphQLCall.Callback<GetSessionQuery.Data> callback ){
        client.query(GetSessionQuery.builder().userId(deviceId).build()).enqueue(callback);
    }

    @SuppressWarnings("unchecked")
    // Subscription methods
    public void subscribeToSession(String sessionId, AppSyncSubscriptionCall.Callback<SubscribeToSessionSubscription.Data> callback){
        SubscribeToSessionSubscription subscription = SubscribeToSessionSubscription.builder().sessionId(sessionId).build();
        subscriptionWatcher = client.subscribe(subscription);
        subscriptionWatcher.execute(callback);
    }

    @SuppressWarnings("unchecked")
    public void subscribeToBeats (String sessionId, AppSyncSubscriptionCall.Callback callback ){
        SubscribeToBeatsSubscription subscription = (SubscribeToBeatsSubscription.builder().sessionId(sessionId)).build();
        subscriptionWatcher = client.subscribe(subscription);
        subscriptionWatcher.execute(callback);
    }


    private List<Beat> sess1_getBeatList(List<GetSessionQuery.Beat> beats){
        List<Beat> rtn = new LinkedList<Beat>();
        if(beats !=null) {
            for (GetSessionQuery.Beat beat : beats) {
                int start = beat.start() != null ? beat.start() : -1;
                int stop = beat.stop() != null ? beat.stop() : -1;
                List<Double> val = beat.val();


                List<GetSessionQuery.Condition> conds = beat.conditions() != null ? beat.conditions() : new LinkedList<GetSessionQuery.Condition>();
                List<Condition> conditionList = new LinkedList<>();

                for (GetSessionQuery.Condition con : conds) {
                    String name = con.name();
                    Double conf = con.conf();
                    Condition condition = new Condition(name, conf);
                    conditionList.add(condition);
                }


                Beat b = new Beat(start, stop, val, conditionList);
                rtn.add(b);
            }
            return rtn;
        } else {
            Log.w("Get Session", "Null beat list. Returning Null");
            return null;
        }
    }


    private List<Beat> sess2_getBeatList(List<SubscribeToSessionSubscription.Beat> beats){
        List<Beat> rtn = new LinkedList<Beat>();
        if(beats !=null) {
            for (SubscribeToSessionSubscription.Beat beat : beats) {
                int start = beat.start() != null ? beat.start() : -1;
                int stop = beat.stop() != null ? beat.stop() : -1;
                List<Double> val = beat.val();


                List<SubscribeToSessionSubscription.Condition> conds = beat.conditions() != null ? beat.conditions() : new LinkedList<SubscribeToSessionSubscription.Condition>();
                List<Condition> conditionList = new LinkedList<>();

                for (SubscribeToSessionSubscription.Condition con : conds) {
                    String name = con.name();
                    Double conf = con.conf();
                    Condition condition = new Condition(name, conf);
                    conditionList.add(condition);
                }


                Beat b = new Beat(start, stop, val, conditionList);
                rtn.add(b);
            }
            return rtn;
        } else {
            Log.w("SubscribeToSession", "Null beat list. Returning Null");
            return null;
        }
    }

    private List<Beat> sess3_getBeatList(List<SubscribeToBeatsSubscription.Beat> beats){
        List<Beat> rtn = new LinkedList<Beat>();
        if(beats !=null) {
            for (SubscribeToBeatsSubscription.Beat beat : beats) {
                int start = beat.start() != null ? beat.start() : -1;
                int stop = beat.stop() != null ? beat.stop() : -1;
                List<Double> val = beat.val();


                List<SubscribeToBeatsSubscription.Condition> conds = beat.conditions() != null ? beat.conditions() : new LinkedList<SubscribeToBeatsSubscription.Condition>();
                List<Condition> conditionList = new LinkedList<>();

                for (SubscribeToBeatsSubscription.Condition con : conds) {
                    String name = con.name();
                    Double conf = con.conf();
                    Condition condition = new Condition(name, conf);
                    conditionList.add(condition);
                }


                Beat b = new Beat(start, stop, val, conditionList);
                rtn.add(b);
            }
            return rtn;
        } else {
            Log.w("SubscribeToSession", "Null beat list. Returning Null");
            return null;
        }
    }


    public Session mapSession(SubscribeToBeatsSubscription.Data data){
        Session s=null;
        if(data.subscribeToBeats()!=null){
            String sessionId= data.subscribeToBeats().sessionId() !=null? data.subscribeToBeats().sessionId() : "";
            String userId= data.subscribeToBeats().userId() !=null ? data.subscribeToBeats().userId() : "";
            String deviceId= data.subscribeToBeats().deviceId() !=null ? data.subscribeToBeats().deviceId() : "";

            double freq = 200;
            String status = data.subscribeToBeats().status()!=null ? data.subscribeToBeats().status() : "unknown";
            List<Double> vals = data.subscribeToBeats().data();


            List<Beat> beats = this.sess3_getBeatList(data.subscribeToBeats().beats());

            s = new Session(sessionId, deviceId, userId, freq, vals,status, beats );
        }else {
            Log.w("Subscribe to Beats", "Null session response. Retutning null");
        }

        return s;

    }
    public Session mapSession(SubscribeToSessionSubscription.Data data){
        Session s=null;
        if(data.subscribeToSession()!=null){
            String sessionId= data.subscribeToSession().sessionId() !=null? data.subscribeToSession().sessionId() : "";
            String userId= data.subscribeToSession().userId() !=null ? data.subscribeToSession().userId() : "";
            String deviceId= data.subscribeToSession().deviceId() !=null ? data.subscribeToSession().deviceId() : "";

            double freq = 200;
            String status = data.subscribeToSession().status()!=null ? data.subscribeToSession().status() : "unknown";

            // Since we are getting an update of this kind we can assume that there will be data
            List<Double> vals = data.subscribeToSession().data() ;
            List<Beat> beats = this.sess2_getBeatList(data.subscribeToSession().beats());

            s = new Session(sessionId, deviceId, userId, freq, vals,status, beats );
        }else {
            Log.w("Subscribe to Session", "Null session response. Retutning null");
        }

        return s;
    }
    public Session mapSession(GetSessionQuery.Data data){
        Session s=null;
        if(data.getSession()!=null){
            String sessionId= data.getSession().sessionId() !=null? data.getSession().sessionId() : "";
            String userId= data.getSession().userId() !=null ? data.getSession().userId() : "";
            String deviceId= data.getSession().deviceId() !=null ? data.getSession().deviceId() : "";

            double freq = 200;
            String status = data.getSession().status()!=null ? data.getSession().status() : "unknown";
            List<Double> vals = data.getSession().data();


            List<Beat> beats = this.sess1_getBeatList(data.getSession().beats());

            s = new Session(sessionId, deviceId, userId, freq, vals,status, beats );
        }else {
            Log.w("getSession", "Null session response. Retutning null");
        }

        return s;
    }
}