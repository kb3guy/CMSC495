package capstone.cmsc495.ekganalyzer;

/**
 * Condition object for integration with AWS
 * @see CMSCApiClient
 */
public class Condition{
    public String name;
    public double conf;

    public Condition(String name, double conf){
        this.name = name;
        this.conf = conf;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setConf(double conf) {
        this.conf = conf;
    }

    public String getName() {
        return name;
    }

    public double getConf() {
        return conf;
    }
}