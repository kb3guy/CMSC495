package capstone.cmsc495.ekganalyzer;

import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.webkit.WebView;


public class RhythmsActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;

    // Stores correct URL to load when moving from portrait to landscape, etc
    private String url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/normal-sinus-rhythm-on-ecg";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rhythms);
        setTitle(R.string.sinus_rhythm);

        // Setup Video
        WebView web = findViewById(R.id.webViewVideos);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        web.getSettings().setAllowContentAccess(true);
        web.getSettings().setLoadsImagesAutomatically(true);
        web.getSettings().setSupportMultipleWindows(false);
        web.getSettings().setSupportZoom(false);
        web.setVerticalScrollBarEnabled(false);
        web.setHorizontalScrollBarEnabled(false);

        Log.v("RhythmsActivity", url);

        web.loadUrl(url);

        // Set up a custom tool bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the action bar with an item
        ActionBar actionBar = getSupportActionBar();
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }// End if

        // Set the drawer layout A.K.A the navigation bar
        drawerLayout = findViewById(R.id.drawer_layout);
        final RhythmsActivity thisActivity = this;

        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Portrait view navigation bar
            NavigationView navigationView = findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    menuItem.setChecked(true);
                    drawerLayout.closeDrawers();

                    switch (menuItem.getItemId()) {
                        case R.id.historyList:
                            Intent intent = new Intent(thisActivity, HistoryActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.live_ekg:
                            intent = new Intent(thisActivity, LiveEKGActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.log_out:
                            // ##### TO DO: Log user out


                            intent = new Intent(thisActivity, LoginActivity.class);
                            startActivity(intent);
                            return true;
                        default:
                            return true;

                    }// End switch statement
                }// End onNavigationItemSelected
            });// End closure
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.rhythms_menu, menu);
        return true;
    }// End onCreateOptionsMenu() Method

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;
        WebView web = findViewById(R.id.webViewVideos);

        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(Gravity.START);
                return true;
            case R.id.historyList:
                intent = new Intent(this, HistoryActivity.class);
                startActivity(intent);
                return true;
            case R.id.live_ekg:
                intent = new Intent(this, LiveEKGActivity.class);
                startActivity(intent);
                return true;
            case R.id.atrial_fibrillation:
                // Set title
                setTitle(item.getTitle());

                /// Go to Atrial Fibrillation URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/atrial-fibrillation";
                web.loadUrl(url);
                return true;
            case R.id.atrial_flutters:
                // Set title
                setTitle(item.getTitle());

                // Go to Atrial Flutters URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/atrial-flutter";
                web.loadUrl(url);
                return true;
            case R.id.asystole:
                // Set title
                setTitle(item.getTitle());

                // Go to Asystole URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/pulseless-electrical-activity-asystole";
                web.loadUrl(url);
                return true;
            case R.id.bundle_block:
                // Set title
                setTitle(item.getTitle());

                // Go to Bundle Block URL
                url = "https://www.sharecare.com/health/circulatory-system-health/wha-left-bundle-branch-block";
                web.loadUrl(url);
                return true;
            case R.id.dysrhythmia:
                // Set title
                setTitle(item.getTitle());

                // Go to Dysrhythmia URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/antiarrhythmics";
                web.loadUrl(url);
                return true;
            case R.id.heart_failure:
                // Set title
                setTitle(item.getTitle());

                // Go to Heart Failure URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/heart-failure/v/what-is-heart-failure";
                web.loadUrl(url);
                return true;
            case R.id.myocardial:
                // Set title
                setTitle(item.getTitle());

                // Go to Norm URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/coronary-artery-disease/v/heart-attack-myocardial-infarct-diagnosis";
                web.loadUrl(url);
                return true;
            case R.id.myocarditis:
                // Set title
                setTitle(item.getTitle());

                // Go to Myocarditis URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/myocarditis-and-pericarditis/v/what-is-myocarditis-and-pericarditis";
                web.loadUrl(url);
                return true;
            case R.id.sinus_rhythm:
                // Set title
                setTitle(item.getTitle());

                // Go to Normal Sinus Rhythm URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/dysrhythmias-and-tachycardias/v/normal-sinus-rhythm-on-ecg";
                web.loadUrl(url);
                return true;
            case R.id.valvular_disease:
                // Set title
                setTitle(item.getTitle());

                // Go to Norm URL
                url = "https://www.khanacademy.org/science/health-and-medicine/circulatory-system-diseases/heart-valve-diseases/v/valvular-heart-disease-diagnosis-and-treatment";
                web.loadUrl(url);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }// End switch statement
    }// End onOptionsItemsSelected() Method

}// End RhythmsActivity class
