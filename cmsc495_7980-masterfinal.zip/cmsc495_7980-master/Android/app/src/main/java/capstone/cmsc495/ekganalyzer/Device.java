package capstone.cmsc495.ekganalyzer;

import com.google.gson.Gson;

/**
 * Device object for integration with AWS
 * @see CMSCApiClient
 */
class Device{
    String deviceId;
    String deviceStatus;
    String userId;
    String sessionId;
    private static Gson mapper = new Gson();



    public Device(String deviceId, String deviceStatus, String userId, String sessionId){
        this.deviceId = deviceId;
        this.deviceStatus=deviceStatus;
        this.userId=userId;
        this.sessionId=sessionId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public String toJson(){
        return mapper.toJson(this);
    }
}