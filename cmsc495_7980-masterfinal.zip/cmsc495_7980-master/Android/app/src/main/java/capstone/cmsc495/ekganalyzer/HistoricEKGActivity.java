package capstone.cmsc495.ekganalyzer;

/**
 * @Purpose this activity holds the Historic EKG
 * @author: Deo & Jon Simmons
 * @version 1
 * @since 12-13-2018
 */

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.TextView;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.google.gson.Gson;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HistoricEKGActivity extends AppCompatActivity {


    public static final String TAG = "HistoricEKGActivity";
    private final LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
    private int lastX = 0;  // Last x chart value

    // Heartbeat variables
    private double beatLength;  // Time length of beat
    private int heartRate = 0;  // Heart rate in bpm
    TextView textHeartRate; // TextView of bpm output

    // Condition variables
    List<Condition> conditions = new ArrayList<>();  // Conditions found + highest confidence found for each
    TextView textConditions;  // TextView of conditions output

    private DrawerLayout drawerLayout;
    private CMSCApiClient appSyncApi;
    private Archive archive;  // TimeStamp value of archive being retrieved
    private Runnable timer;
    private Handler handler;

    boolean bolBadConditionFound = false; // Has a negative, non-normal condition been found?

    /**
     * onCreate() = when activity is first initialized
     * @param savedInstanceState Saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Inflate the view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historic_ekg);

        // Set up a custom tool bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the action bar with an item
        ActionBar actionBar = getSupportActionBar();
        System.out.println(actionBar);
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }// End if


        // Set the drawer layout A.K.A the navigation bar
        drawerLayout = findViewById(R.id.drawer_layout);

        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Portrait view navigation bar
            NavigationView navigationView = findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Intent intent;

                    menuItem.setChecked(true);
                    drawerLayout.closeDrawers();

                    switch (menuItem.getItemId()) {
                        case R.id.rhythms:
                            intent = new Intent(HistoricEKGActivity.this, RhythmsActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.live_ekg:
                            intent = new Intent(HistoricEKGActivity.this, LiveEKGActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.log_out:
                            AWSMobileClient.getInstance().signOut();
                            intent = new Intent(HistoricEKGActivity.this, LoginActivity.class);
                            startActivity(intent);
                            return true;
                        default:
                            return true;

                    }// End switch statement
                }// End onNavigationItemSelected
            });// End closure
        } // if portrait view

        // Get TimeStamp of archive being retrieved
        archive = new Gson().fromJson(getIntent().getStringExtra("archive_object"), Archive.class);
        final String dateString = archive.getTimeStamp();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);

        try {
            Date date = dateFormat.parse(dateString);
            dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US);

            setTitle(dateFormat.format(date));
        } catch (ParseException e) {
            setTitle(archive.getTimeStamp());
            Log.e(TAG, e.getMessage());
        }

        // Get needed TextView and GraphView objects
        textHeartRate = findViewById(R.id.textBPM);
        textConditions = findViewById(R.id.textConditions);
        GraphView ekgChart = findViewById(R.id.ekgGraphView);

        // Update Condition Info
        updateConditions("Retrieving Data...");

        // Customize the stroke
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0xffEEEEEE);
        paint.setStrokeWidth(4);
        series.setCustomPaint(paint);


        // Add mock TEST data to chart
        ekgChart.addSeries(series);

        // Customize viewport
        Viewport viewport = ekgChart.getViewport();
        viewport.setYAxisBoundsManual(true);
        viewport.setMinY(-2);
        viewport.setMaxY(2);
        viewport.setScrollable(true);
        viewport.setXAxisBoundsManual(true);
        viewport.setMinX(0);
        viewport.setMaxX(1000);
    }

    @Override
    protected void onResume() {
        super.onResume();

        handler = new Handler();
        timer = new Runnable() {
            @Override
            public void run() {

                if(lastX >= archive.getBeats().get(0).getVal().size()) return;
                Beat beat = archive.getBeats().get(0);

                displayCondition(beat);
                double y = beat.getVal().get(lastX);
                double x = lastX++;

                DataPoint dataPoint = new DataPoint(x, y);
                series.appendData(dataPoint, true, 400);
                calculateBPM(beat);

                handler.postDelayed(this, 10);
            }
        };
        handler.postDelayed(timer, 10);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(timer);
        super.onPause();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case android.R.id.home:
                drawerLayout.openDrawer(Gravity.START);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }// End switch statement

    }// End onOptionsItemSelected() Method


    /**
     * Updates Conditions TextField on main UI thread
     * @param message String message to change Conditions TextField to
     */
    void updateConditions(String message) {
        final String msg = message;  // needs to be final to work

        // Only update when in portrait mode
        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (textConditions != null) {
                        textConditions.setText(msg);
                    } else {
                        Log.v(TAG, "textConditions null in portrait view?");
                    }
                }
            });
        }
    } // --------------------------------------------------------

    void calculateBPM(Beat beat){
        /*-----------------------
             Update Heartbeat
         ------------------------*/
        // @TODO Need frequency in archive data instead of hardcoded 200hz
        beatLength = (beat.getStop() - beat.getStart()) / 200;

        // Total time between last 6 beats
        heartRate = (int) (60 / beatLength);
        updateBPM(heartRate);
    }

    /**
     * Updates conditions
     * @param beat
     */
    void displayCondition(Beat beat) {
        boolean bolFound;

        StringBuilder sbConditions = new StringBuilder();

        Log.v(TAG, String.format("Condition size = %s, lastX = %d", beat.getConditions().size(), lastX));

        if(lastX >= beat.getConditions().size()) return;

        Condition condition = beat.getConditions().get(lastX);

        bolFound = false;

        // Is the condition negative (not normal)?
        if (! condition.getName().equals("normal")) {
            bolBadConditionFound = true;
        }

        // Check if the condition was already found before
        for (Condition conditionPreviouslyFound : conditions) {
            if (condition.getName().equals(conditionPreviouslyFound.getName())) {
                bolFound = true;

                // If new confidence value is greater than previous levels,
                // increase confidence to new confidence level
                if (condition.getConf() > conditionPreviouslyFound.getConf()) {
                    conditionPreviouslyFound.setConf(condition.getConf());
                }
            }
        }

        // If condition is newly discovered, add to list of conditions found
        if (!bolFound) {
            conditions.add(condition);
        }

        // Build conditions output string; ignore "normal" if a negative condition was found
        if (bolBadConditionFound) {
            for (Condition conditionPreviouslyFound : conditions) {
                if (! conditionPreviouslyFound.getName().equalsIgnoreCase("normal")) {
                    sbConditions.append(conditionPreviouslyFound.getName());
                    sbConditions.append(" (");
                    sbConditions.append((int) (conditionPreviouslyFound.getConf() * 100));
                    sbConditions.append("%)\n");
                }
            }
        } else {
            sbConditions.append("Normal");
        }

        // Set conditions TextView to new conditions summary
        updateConditions(sbConditions.toString());
    }

    /**
     * Updates Heart Rate TextField on main UI thread
     * @param bpm Heart rate (bpm) to change Conditions TextField to
     */
    void updateBPM(final int bpm) {

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textHeartRate.setText(String.valueOf(bpm));
            }
        });
    }// --------------------------------------------------------


    /* ############################  FOR TEST DATA ONLY! ############################
    @Override
    public void onResume() {
        super.onResume();
        millisecsPassed = 1;

        new Thread(new Runnable() {

            @Override
            public void run() {
                int millisDelay = 1000 / valuesPerSecond;  // Delay between each mock value created

                // Add 5000 new entries
                for (int i = 0; i < 5000; i++) {
                    int totalTime = 0; // Total time between last 6 beats (so for 5 beats to complete)

                    // Total time between last 6 beats
                    for (int time : timeBetweenLast6Beats) {
                        totalTime += time;
                    }
                    heartRate = 360000 / totalTime;

                    // final version of heartRate so it can be used in the UI thread
                    final int hRate = heartRate;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            addEntry();
                            textHeartRate.setText("" + hRate);
                        }
                    });

                    // sleep to slow down the add of entries. 5 millis delay = 200hz
                    try {
                        Thread.sleep(millisDelay);
                    } catch (InterruptedException e) {
                        // manage error ...
                    }

                    millisecsPassed = millisecsPassed + 5;
                }
            }
        }).start();
    } // onResume() --------------------------------------------------


    // add random data to graph
    private void addEntry() {
        DataPoint dataPoint;  // New value

        // Create and display max 1000 values on the viewport and scroll to end
        // Display a fake beat every (170/1000) seconds
        int mod = lastX % 170;

        if (mod == 169) {
            numBeats++;

            // Set millisecond counter of the last beat and place into array of last 6 beat times
            timeBetweenLast6Beats[numBeats % 6] = (lastX * 5) - timeOfLastBeat;
            timeOfLastBeat = lastX * 5;

            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 7);
        } else if ((mod > 3) && (mod < 7)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 200);
        } else if ((mod > 0) && (mod < 9)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 80);
        } else if ((mod > 9) && (mod < 12)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * -70);
        } else if ((mod > 11) && (mod < 14)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * -20);
        } else {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 7);
        }

        // Add value to viewport and scroll to end
        synchronized (series) {
            series.appendData(dataPoint, true, 1000);
        }
    } // addEntry() ---------------------------------------------------
    ################################# END TEST DATA ################################
    */
} // HistoricEKGActivity class
