package capstone.cmsc495.ekganalyzer;

/**
 * @Purpose this activity holds the Live EKG
 * @author: Deo & Jon Simmons
 * @version 1
 * @since 12-15-2018
 */

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Paint;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.TextView;

import com.amazonaws.amplify.generated.graphql.GetAccountQuery;
import com.amazonaws.amplify.generated.graphql.SubscribeToBeatsSubscription;
import com.amazonaws.amplify.generated.graphql.SubscribeToSessionSubscription;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobileconnectors.appsync.AppSyncSubscriptionCall;
import com.apollographql.apollo.GraphQLCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;
import com.jjoe64.graphview.GraphView;
import com.jjoe64.graphview.Viewport;
import com.jjoe64.graphview.series.DataPoint;
import com.jjoe64.graphview.series.LineGraphSeries;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Nonnull;


public class LiveEKGActivity extends AppCompatActivity {

    private final LineGraphSeries<DataPoint> series = new LineGraphSeries<>();
    private int lastX = 0;  // Last x chart value
    private Handler handler;
    private Runnable timer;
    private ArrayList<Double> values = new ArrayList<>();
    public static final String TAG = "LiveEKGActivity";

    // Heartbeat variables
    private double[] beatLengths = {.8,.8,.8,.8,.8,.8};
    private double totalBeatsLength = 0.0;  // Length of last 6 beats, total
    private int beatIndex = 0;  // Current index to beatLengths array
    private int heartRate = 0;  // Heart rate in bpm
    TextView textHeartRate;  // TextView for HeartRate output

    // Condition variables
    List<Condition> conditions = new ArrayList<>();  // Conditions found + highest confidence found for each
    TextView textConditions;  // TextView for Conditions output

    private DrawerLayout drawerLayout;  // Layout
    public CMSCApiClient appSyncApi;  // API

    StringBuilder sbConditions;  // List of conditions found

    /**
     * onCreate() = when activity is first initialized
     * @param savedInstanceState Saved instance state
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Inflate the view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_live_ekg);

        // Get needed TextView and GraphView objects
        textHeartRate = findViewById(R.id.textBPM);
        textConditions = findViewById(R.id.textConditions);
        GraphView ekgChart = findViewById(R.id.ekgGraphView);

        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Update Condition Info
            // @TODO: Use data binding / Android resources for conditions?
            updateConditions("Analyzing EKG...");
        }

        // Initiate AWS/device connection
        appSyncApi = new CMSCApiClient(this.getApplicationContext());

        // Customize the stroke
        Paint paint = new Paint();
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setColor(0xffEEEEEE);
        paint.setStrokeWidth(4);
        series.setCustomPaint(paint);

        // Add mock TEST data to chart
        ekgChart.addSeries(series);

        // Customize viewport
        Viewport viewport = ekgChart.getViewport();
        viewport.setYAxisBoundsManual(false);
        viewport.setScrollable(true);
        viewport.setXAxisBoundsManual(true);
        viewport.setMinX(0);
        viewport.setMaxX(1000);

        Log.i(TAG, ((EKGapp) getApplication()).getUserID());

        // Retrieve account and subscribe to live EKG data session
        appSyncApi.getAccount(((EKGapp) getApplication()).getUserID(),
                new GraphQLCall.Callback<GetAccountQuery.Data>() {
                    @Override
                    public void onResponse(@Nonnull Response<GetAccountQuery.Data> response) {
                        final Account account = appSyncApi.mapAccount(response.data());

                        if (account != null) {
                            // Set the session id for other uses in the future
                            ((EKGapp) getApplication()).setSessionID(account.sessionId);

                            Log.i(TAG, account.sessionId);

                            if (account.sessionId != null) {
                                /*----------------------------------------------------------------------
                                *  subscribeToSession() - For EKG chart data (data added in onResume())
                                -----------------------------------------------------------------------*/
                                appSyncApi.subscribeToSession(account.sessionId,
                                        new AppSyncSubscriptionCall.Callback<SubscribeToSessionSubscription.Data>() {
                                            @Override
                                            public void onResponse(@Nonnull Response<SubscribeToSessionSubscription.Data> response) {
                                                // New Session data received from subscription
                                                if (response.data() == null) {
                                                    Log.i(TAG, "No Data.");
                                                } else {
                                                    Log.i(TAG, response.data().toString());
                                                }

                                                Session session = appSyncApi.mapSession(response.data());

                                                for (double value : session.getData()) {
                                                    values.add(value);
                                                    Log.e(TAG, String.valueOf(lastX) + ", " +String.valueOf(value));
                                                }
                                            }

                                            @Override
                                            public void onFailure(@Nonnull ApolloException e) {
                                                // Invoked on error
                                                Log.e(TAG, e.toString());
                                                updateConditions("Error: AWS Session Connection Failure.");
                                            }

                                            @Override
                                            public void onCompleted() {
                                                // Invoked when subscription is terminated
                                                Log.i(TAG, "Session Subscription completed");
                                            }
                                        });

                                /*------------------------------------------------------------
                                 *  subscribeToBeats() - For heart rate and conditions found
                                 ------------------------------------------------------------*/
                                appSyncApi.subscribeToBeats(((EKGapp) getApplication()).getSessionID(),
                                        new AppSyncSubscriptionCall.Callback<SubscribeToBeatsSubscription.Data>() {
                                            @Override
                                            public void onResponse(@Nonnull Response<SubscribeToBeatsSubscription.Data> response) {
                                                // New Session data with Beats received from subscription
                                                if (response.data() == null) {
                                                    Log.i(TAG, "No data.");
                                                } else {
                                                    Log.i(TAG, response.data().toString());
                                                }

                                                Session session = appSyncApi.mapSession(response.data());

                                                // Process beats for heart rate and conditions
                                                for (Beat beat : session.getBeats()) {
                                                    beatIndex++;
                                                    beatLengths[beatIndex % 6] =
                                                            (beat.getStop() - beat.getStart()) / session.getFrequency();
                                                    totalBeatsLength = 0;
                                                    boolean bolFound;
                                                    StringBuilder sbConditions = new StringBuilder();

                                                    // Total time between last 6 beats
                                                    for (double time : beatLengths) {
                                                        totalBeatsLength += time;
                                                    }
                                                    heartRate = (int) (360 / totalBeatsLength);
                                                    updateBPM(heartRate);

                                                    // Check conditions found
                                                    for (Condition condition : beat.getConditions()) {
                                                        bolFound = false;

                                                        // Check if the condition was already found before
                                                        for (Condition conditionPreviouslyFound : conditions) {
                                                            if (condition.getName().equals(conditionPreviouslyFound.getName())) {
                                                                bolFound = true;

                                                                // If new confidence value is greater than previous levels,
                                                                // increase confidence to new confidence level
                                                                if (condition.getConf() > conditionPreviouslyFound.getConf()) {
                                                                    conditionPreviouslyFound.setConf(condition.getConf());
                                                                }
                                                            }
                                                        }

                                                        // If condition is newly discovered, add to list of conditions found
                                                        if (!bolFound) {
                                                            conditions.add(condition);
                                                        }

                                                        // Build conditions output string
                                                        for (Condition conditionPreviouslyFound : conditions) {
                                                            sbConditions.append(conditionPreviouslyFound.getName());
                                                            sbConditions.append(" (");
                                                            sbConditions.append((int) (conditionPreviouslyFound.getConf() * 100));
                                                            sbConditions.append("%)\n");
                                                        }

                                                        // Set conditions TextView to new conditions summary
                                                        updateConditions(sbConditions.toString());
                                                    } // for loop through conditions
                                                } // for loop through beats
                                            } // onResponse()

                                            @Override
                                            public void onFailure(@Nonnull ApolloException e) {
                                                // Invoked on error
                                                Log.e(TAG, e.toString());
                                                updateConditions("- Device Error -");
                                            }

                                            @Override
                                            public void onCompleted() {
                                                // Invoked when subscription is terminated
                                                Log.i(TAG, "Subscription completed");
                                            }
                                        });
                            } else {
                                Log.e(TAG, "Session object is null");
                                updateConditions("Error retrieving session");
                            }// if session is not null
                        } else {
                            Log.e(TAG, "Account object is null");
                            updateConditions("Error retrieving account");
                        } // if account is not null
                    } // onResponse()


                    @Override
                    public void onFailure(@Nonnull ApolloException e) {
                        updateConditions("Error: AWS Connection Failure.");
                    }
                });// appSyncApi.getAccount()
        // Set up a custom tool bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the action bar with an item
        ActionBar actionBar = getSupportActionBar();
        System.out.println(actionBar);
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }// End if

        // Set the drawer layout A.K.A the navigation bar
        drawerLayout = findViewById(R.id.drawer_layout);
        final LiveEKGActivity thisActivity = this;


        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            // Portrait view navigation bar
            NavigationView navigationView = findViewById(R.id.nav_view);
            navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                    Intent intent;

                    menuItem.setChecked(true);
                    drawerLayout.closeDrawers();

                    switch (menuItem.getItemId()) {
                        case R.id.rhythms:
                            intent = new Intent(thisActivity, RhythmsActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.historyList:
                            intent = new Intent(thisActivity, HistoryActivity.class);
                            startActivity(intent);
                            return true;
                        case R.id.log_out:
                            AWSMobileClient.getInstance().signOut();
                            intent = new Intent(thisActivity, LoginActivity.class);
                            startActivity(intent);
                            return true;
                        default:
                            return true;

                    }// End switch statement
                }// End onNavigationItemSelected
            });// End closure
        } // if in portrait orientation
    } // onCreate() -----------------------------------------------------------


    @Override
    protected void onResume() {
        super.onResume();

        Log.v(TAG, "onResume()");

        // This is where the data is added to the chart
        handler = new Handler();
        timer = new Runnable() {
            @Override
            public void run() {

                Log.v(TAG, String.valueOf(lastX) + ", " + String.valueOf(values.size()));

                if(lastX < values.size()) {
                    double y = values.get(lastX);
                    double x = lastX++;

                    DataPoint dataPoint = new DataPoint(x, y);
                    series.appendData(dataPoint, true, 1000);
                }

                handler.postDelayed(this, 5);
            }
        };
        handler.postDelayed(timer, 5);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(timer);
        super.onPause();
    }

    /**
     * Updates Conditions TextField on main UI thread
     * @param message String message to change Conditions TextField to
     */
    void updateConditions(String message) {
        final String msg = message;  // needs to be final to work

        // Only update when in portrait mode
        if (this.getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    textConditions = findViewById(R.id.textConditions);

                    if (textConditions != null) {
                        textConditions.setText(msg);
                    } else {
                        Log.i(TAG, "textConditions null in portrait view?");
                    }
                }
            });
        }
    } // --------------------------------------------------------


    /**
     * Updates Heart Rate TextField on main UI thread
     * @param bpm Heart rate (bpm) to change Conditions TextField to
     */
    void updateBPM(int bpm) {
        final int BPM = bpm;  // needs to be final to work

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                textHeartRate.setText(BPM);
            }
        });
    }// --------------------------------------------------------



    /**
     * Process main menu changes
     * @param item Menu item selected
     * @return Successfully started new activity
     */
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent intent;

        switch (item.getItemId()) {
            case android.R.id.home:
                drawerLayout.openDrawer(Gravity.START);
                return true;
            case R.id.historyList:
                intent = new Intent(this, HistoryActivity.class);
                startActivity(intent);
                return true;
            case R.id.rhythms:
                intent = new Intent(this, RhythmsActivity.class);
                startActivity(intent);
                return true;
            default:
                return super.onOptionsItemSelected(item);

        }// End switch statement
    }// End onOptionsItemSelected() Method


/* ###################### FOR TESTING ONLY ##############################
        millisecsPassed = 1;

        new Thread(new Runnable() {

            @Override
            public void run() {
                int millisDelay = 1000 / valuesPerSecond;  // Delay between each mock value created

                // Add 5000 new entries
                for (int i = 0; i < 5000; i++) {
                    int totalTime = 0; // Total time between last 6 beats (so for 5 beats to complete)

                    // Total time between last 6 beats
                    for (int time : timeBetweenLast6Beats) {
                        totalTime += time;
                    }
                    heartRate = 360000 / totalTime;

                    // final version of heartRate so it can be used in the UI thread
                    final int hRate = heartRate;

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            addEntry();
                            textHeartRate.setText("" + hRate);
                        }
                    });

                    // sleep to slow down the add of entries. 5 millis delay = 200hz
                    try {
                        Thread.sleep(millisDelay);
                    } catch (InterruptedException e) {
                        // manage error ...
                    }

                    millisecsPassed = millisecsPassed + 5;
                }
            }
        }).start();
    } // onResume() --------------------------------------------------


    // add random data to graph
    private void addEntry() {
        DataPoint dataPoint;  // New value

        // Create and display max 1000 values on the viewport and scroll to end
        // Display a fake beat every (170/1000) seconds
        int mod = lastX % 170;

        if (mod == 169) {
            numBeats++;

            // Set millisecond counter of the last beat and place into array of last 6 beat times
            timeBetweenLast6Beats[numBeats % 6] = (lastX * 5) - timeOfLastBeat;
            timeOfLastBeat = lastX * 5;

            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 7);
        } else if ((mod > 3) && (mod < 7)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 200);
        } else if ((mod > 0) && (mod < 9)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 80);
        } else if ((mod > 9) && (mod < 12)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * -70);
        } else if ((mod > 11) && (mod < 14)) {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * -20);
        } else {
            dataPoint = new DataPoint(lastX++, RANDOM.nextDouble() * 7);
        }

        // Add value to viewport and scroll to end
        synchronized (series) {
            series.appendData(dataPoint, true, 1000);
        }
    } // addEntry() ---------------------------------------------------
    // #####################   END TESTING DATA   ########################
    */

} // LiveEKGActivity class