package capstone.cmsc495.ekganalyzer;


import java.util.List;

/**
 * Beat object for integration with AWS
 * @see CMSCApiClient
 */
public class Beat {
    public int start;
    public int stop;
    public List<Double> val;
    public List<Condition> conditions;

    public Beat(int start, int stop, List<Double> val, List<Condition>conditions){
        this.start = start;
        this.stop = stop;
        this.val = val;
        this.conditions = conditions;
    }

    public int getStart() {
        return start;
    }

    public int getStop() {
        return stop;
    }

    public List<Double> getVal() {
        return val;
    }

    public List<Condition> getConditions() {
        return conditions;
    }
}
