package capstone.cmsc495.ekganalyzer;

import java.util.List;

/**
 * Session object for integration with AWS
 * @see CMSCApiClient
 */
class Session{
    public String sessionId;
    public String deviceId;
    public String userId;
    public double frequency;
    public List<Double> data;
    public String status;
    public List<Beat> beats;


    public Session(String sessionId, String deviceId, String userId,
                   double frequency, List<Double> data, String status, List<Beat> beats){
            this.sessionId = sessionId;
            this.deviceId = deviceId;
            this.userId= userId;
            this.frequency = frequency;
            this.data = data;
            this.status = status;
            this.beats = beats;
    }

    List<Double> getData() {
        return data;
    }

    List<Beat> getBeats() {
        return beats;
    }

    public double getFrequency() {
        return frequency;
    }
}