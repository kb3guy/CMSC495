package capstone.cmsc495.ekganalyzer;
/**
 * @author: Deo Kalule & Jon Simmons
 * @purpose: To log into the EKG Analyzer app
 * @since 11-18-2018
 */

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.amplify.generated.graphql.GetAccountQuery;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.UserState;
import com.amazonaws.mobile.client.UserStateDetails;
import com.amazonaws.mobile.client.results.SignInResult;
import com.apollographql.apollo.GraphQLCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;

import javax.annotation.Nonnull;

public class LoginActivity extends AppCompatActivity {

    final String TAG = "LoginActivity";
    EditText emailText;
    EditText passwordText;
    private CMSCApiClient appSyncApi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        emailText = findViewById(R.id.emailTextField);
        passwordText = findViewById(R.id.passwordTextField);

        // Test password and user name
        //emailText.setText(getString(R.string.sample_email));
        //passwordText.setText(getString(R.string.sample_password));

        // Get API Client
        appSyncApi = new CMSCApiClient(this.getApplicationContext());
        AWSMobileClient.getInstance().initialize(getApplicationContext(), new Callback<UserStateDetails>() {

            @Override
            public void onResult(UserStateDetails userStateDetails) {
                // Log the user in if they are already logged in
                if (userStateDetails.getUserState() == UserState.SIGNED_IN) {
                    Intent intent = new Intent(LoginActivity.this, HistoryActivity.class);
                    startActivity(intent);
                }// End if
            }// End function

            @Override
            public void onError(Exception e) {
                Log.e(TAG, e.getMessage());
            }// End function
        }); // End closure

    }// End onCreate() Method

    /**
     * Navigates to the SignUpActivity class
     * @param view the button that was tapped
     */
    public void goToSignUpActivity(View view) {
        Intent intent = new Intent(this, SignUpActivity.class);
        startActivity(intent);
    }// End goToSignUpActivity()


    /**
     * Navigates to the HistoryActivity class
     * @param view the View where the login button was tapped
     */
    public void goToHistoryActivity(View view) {

        final String email = emailText.getText().toString();
        final String password = passwordText.getText().toString();


        // FIXME: The userID and deviceID are retrieved from the history activity,
        // FIXME: since the user might be logged in even after they close the app due to cognito handling signin

        // @todo Get account is just a query. It should be invoked after user has been authenticated
//        appSyncApi.getAccount(email, new GraphQLCall.Callback<GetAccountQuery.Data>() {
//            @Override
//            public void onResponse(@Nonnull Response<GetAccountQuery.Data> response) {
//
//                // Map the response the the appropriate object class. (In this case Account)
//                Account account = appSyncApi.mapAccount(response.data());
//
//                // Set global variables: userID and deviceID
//                ((EKGapp)getApplication()).setUserID(account.getUserId());
//                ((EKGapp)getApplication()).setDeviceID(account.getDeviceId());
//            }
//
//            @Override
//            public void onFailure(@Nonnull ApolloException e) {
//                Log.w("ERR", e.toString());
//            }
//        });

        AWSMobileClient.getInstance().signIn(email, password, null, new Callback<SignInResult>() {
            @Override
            public void onResult(final SignInResult result) {

                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        Log.v(TAG, result.getSignInState().toString());

                        // Check the status of the login and react appropriately
                        switch (result.getSignInState()) {
                            case DONE:
                                // @fixme the user information (userID and deviceID) is being retrieved in the history page from AWSCognito,
                                // @fixme we do not need this code here, its making 2 calls for no reason
//                                appSyncApi.getAccount(email, new GraphQLCall.Callback<GetAccountQuery.Data>() {
//                                    @Override
//                                    public void onResponse(@Nonnull Response<GetAccountQuery.Data> response) {
//                                        if(response.data()!=null){
//                                            Account acc = appSyncApi.mapAccount(response.data());
//
//                                            ((EKGapp)getApplication()).setUserID(acc.getUserId());
//                                            ((EKGapp)getApplication()).setDeviceID(acc.getDeviceId());
//                                        }
//                                    }
//
//                                    @Override
//                                    public void onFailure(@Nonnull ApolloException e) {
//
//                                    }
//                                });
                                Intent intent = new Intent(LoginActivity.this, HistoryActivity.class);
                                startActivity(intent);
                                break;
                            case NEW_PASSWORD_REQUIRED:
                                Toast.makeText(LoginActivity.this, "Please confirm sign-in with new password", Toast.LENGTH_SHORT).show();
                                break;
                            default:
                                Toast.makeText(LoginActivity.this, "Wrong Password/ Email", Toast.LENGTH_SHORT).show();
                        }// End switch statement
                    }// End function
                });// End closure

            }// End on result

            @Override
            public void onError(final Exception e) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {

                        if(e.getMessage().contains("User is not confirmed")) {
                            Intent intent = new Intent(LoginActivity.this, CodeInputActivity.class);
                            startActivity(intent);
                        } else Toast.makeText(LoginActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                        Log.e(TAG, e.getMessage());
                    }// End function
                });// End closure
            }// End function
        });// End signin closure
    }// End goToHistoryActivity() class
}// End LoginActivity class
