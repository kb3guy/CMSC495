package capstone.cmsc495.ekganalyzer;

import android.app.Application;

/**
 * Main application - used to store important global variables
 */
public class EKGapp extends Application {
    private String userID;
    private String deviceID;
    private String sessionID;

    public void setUserID(String userID) {
        this.userID = userID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public void setSessionID(String sessionID) {
        this.sessionID = sessionID;
    }

    public String getUserID() {
        return userID;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public String getSessionID() {
        return sessionID;
    }
}
