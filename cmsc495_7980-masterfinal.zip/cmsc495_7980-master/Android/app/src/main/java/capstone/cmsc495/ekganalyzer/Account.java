package capstone.cmsc495.ekganalyzer;


import com.google.gson.Gson;

/**
 * Account object for integration with AWS
 * @see CMSCApiClient
 */
class Account{
    // public String archiveId;
    public String deviceId;
    public String sessionId;
    public String email;
    public String userId;
    private static Gson mapper = new Gson();


    public Account (String deviceId, String sessionId,  String userId, String email){
//        this.archiveId = archiveId;
        this.deviceId = deviceId; 
        this.sessionId = sessionId; 
        this.email = email;
        this.userId = userId;
    }

    public String getUserId() {
        return userId;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public String getSessionId() { return sessionId; }

    public String toJson(){
        return mapper.toJson(this);
    }
}
