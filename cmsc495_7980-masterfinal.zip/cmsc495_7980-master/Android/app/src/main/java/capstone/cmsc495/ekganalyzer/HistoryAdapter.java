package capstone.cmsc495.ekganalyzer;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.google.gson.Gson;

import javax.annotation.Nonnull;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    private List<Archive> values;
    public static final String TAG = "HistoryAdapter";
    Context context;

    // Provide a reference to the views for each data item
    // Complex data items may need more than one view per item, and
    // you provide access to all the views for a data item in a view holder
    public class ViewHolder extends RecyclerView.ViewHolder {
        // each data item is just a string in this case
        TextView txtHistory;
        public View layout;

        ViewHolder(View v) {
            super(v);
            layout = v;
            txtHistory = v.findViewById(R.id.history_line);

            v.findViewById(R.id.delete_button).setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {
                    int position = getAdapterPosition();

                    // Remove from recycler view
                    remove(position);
                    notifyItemRemoved(position);
                    notifyItemRangeChanged(position, values.size());

                    // Remove from list
                    values.remove(values.get(position));
                }
            });
        }
    }

    public void add(int position, Archive item) {
        values.add(position, item);
        notifyItemInserted(position);
    }

    public void remove(int position) {
        values.remove(position);
        notifyItemRemoved(position);
    }

    // Constructor
    HistoryAdapter(List<Archive> myDataset) {
        values = myDataset;
    }

    // Create new views (invoked by the layout manager)
    @Override
    public @Nonnull HistoryAdapter.ViewHolder onCreateViewHolder(@Nonnull ViewGroup parent,
                                                        int viewType) {
        // create a new view
        LayoutInflater inflater = LayoutInflater.from(
                parent.getContext());
        View v =
                inflater.inflate(R.layout.row_layout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        return new ViewHolder(v);
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(@Nonnull ViewHolder holder, final int position) {
        // Get history item from dataset at this position
        // Replace the contents of the view with that element
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.ENGLISH);
        Date date;



        final String dateString = values.get(position).getTimeStamp();
        context = holder.itemView.getContext();
        try {
            date = dateFormat.parse(dateString);
            dateFormat = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss a", Locale.US);

            holder.txtHistory.setText(dateFormat.format(date));
        } catch (ParseException e) {
            holder.txtHistory.setText(dateString);
            Log.e(TAG, e.getMessage());
        }

        holder.txtHistory.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(context, HistoricEKGActivity.class);

                // Use this extra data to tell HistoricEKGActivity
                // which record to pull (by datetime of archive)

                intent.putExtra("archive_object", new Gson().toJson(values.get(position)));
                context.startActivity(intent);
            }
        });
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return values.size();
    }

}