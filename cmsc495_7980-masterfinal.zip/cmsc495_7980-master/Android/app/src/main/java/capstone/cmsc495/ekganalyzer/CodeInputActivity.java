package capstone.cmsc495.ekganalyzer;

/**
 * @Purpose this activity handles the user sign-up process
 * @author: Deo & Jon Simmons
 * @version 1
 * @since 12-13-2018
 */

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.amazonaws.mobile.client.results.SignUpResult;

public class CodeInputActivity extends AppCompatActivity {

    EditText emailText;
    EditText codeText;
    public static final String TAG = "CodeInputActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_code_input);

        emailText = findViewById(R.id.emailTextField);
        codeText = findViewById(R.id.codeInputText);

    }// End method

    public void confirmSignUp(View view) {

        // Get the strings from the edit texts
        String email = emailText.getText().toString();
        String code = codeText.getText().toString();

        // Validate and confirm sign up
        if(email.isEmpty())
            Toast.makeText(this, "Please fill in an email", Toast.LENGTH_SHORT).show();
        else if(code.isEmpty())
            Toast.makeText(this, "Please fill in the code you received in your email", Toast.LENGTH_SHORT).show();
        else {

            // Confirm sign up
            AWSMobileClient.getInstance().confirmSignUp(email, code, new Callback<SignUpResult>() {
                @Override
                public void onResult(final SignUpResult result) {

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            if(!result.getConfirmationState()){
                                Toast.makeText(CodeInputActivity.this, "Please double check your email or code", Toast.LENGTH_SHORT).show();
                            } else {
                                Intent intent = new Intent(CodeInputActivity.this, LoginActivity.class);
                                startActivity(intent);
                            }// End if statement
                        }// End Method
                    });// End closure


                }// End method

                @Override
                public void onError(final Exception e) {
                    Log.e(TAG, e.getMessage());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(CodeInputActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    });

                }// End method
            });// End closure


        }// End if else statement

    }// End method
}// End class
