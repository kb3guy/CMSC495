package capstone.cmsc495.ekganalyzer;
/**
 * @Purpose this activity holds the EKG history
 * @author: Deo & Jon Simmons
 * @since 11-18-2018
 * @version 1
 */

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.widget.Toast;

import com.amazonaws.amplify.generated.graphql.GetAccountQuery;
import com.amazonaws.amplify.generated.graphql.GetArchivesQuery;
import com.amazonaws.mobile.client.AWSMobileClient;
import com.amazonaws.mobile.client.Callback;
import com.apollographql.apollo.GraphQLCall;
import com.apollographql.apollo.api.Response;
import com.apollographql.apollo.exception.ApolloException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.annotation.Nonnull;

public class HistoryActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private RecyclerView recyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    public CMSCApiClient appSyncApi;
    public static final String TAG = "HistoryActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // Inflate the view
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        recyclerView = findViewById(R.id.historyList);

        // Initiate data/device connection
        appSyncApi = new CMSCApiClient(this.getApplicationContext());

        // Get the user attributes from cognito and set up the recycler view
        AWSMobileClient.getInstance().getUserAttributes(new Callback<Map<String, String>>() {
            @Override
            public void onResult(final Map<String, String> result) {


                // Get the userID and deviceID from cognito
                final String userID = result.get("custom:userID");
                String deviceID = result.get("custom:sensorID");

                // Set the global variables here instead of the login activity where they may not always be called
                ((EKGapp)getApplication()).setUserID(userID);
                ((EKGapp)getApplication()).setDeviceID(deviceID);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        setUpRecyclerView();
                    }// End function
                });// End closure

            }// End method

            @Override
            public void onError(final Exception e) {
                Log.e(TAG, e.getMessage());
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(HistoryActivity.this, e.getMessage(), Toast.LENGTH_SHORT).show();
                    }// End method
                });// End closure
            }
        });


        // Set up a custom tool bar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // Get the action bar with an item
        ActionBar actionBar = getSupportActionBar();
        System.out.println(actionBar);
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true);
            actionBar.setHomeAsUpIndicator(R.drawable.ic_menu);
        }// End if

        // Set the drawer layout A.K.A the navigation bar
        drawerLayout = findViewById(R.id.drawer_layout);
        final HistoryActivity thisActivity = this;

        NavigationView navigationView = findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {
                Intent intent;

                menuItem.setChecked(true);
                drawerLayout.closeDrawers();

                switch (menuItem.getItemId()) {
                    case R.id.rhythms:
                        intent = new Intent(thisActivity, RhythmsActivity.class);
                        startActivity(intent);
                        return true;
                    case R.id.live_ekg:
                        intent = new Intent(thisActivity, LiveEKGActivity.class);
                        startActivity(intent);
                        return true;
                    case R.id.log_out:
                        AWSMobileClient.getInstance().signOut();
                        intent = new Intent(thisActivity, LoginActivity.class);
                        startActivity(intent);
                        return true;
                    default:
                        return true;

                }// End switch statement
            }// End onNavigationItemSelected
        });// End closure
    }// End onCreate() Method

    private void setUpRecyclerView() {
        Log.v(TAG, "Called setUpRecyclerView() with userID = " + ((EKGapp) getApplication()).getUserID());

        // List of archives by Timestamp
        final List<Archive> archiveList = new ArrayList<>();
        // Create History List
        // Retrieve account and retrieve list of archives/history
        appSyncApi.getAccount(((EKGapp) getApplication()).getUserID(),
                new GraphQLCall.Callback<GetAccountQuery.Data>() {
                    @Override
                    public void onResponse(@Nonnull Response<GetAccountQuery.Data> response) {
                        if (((EKGapp) getApplication()).getDeviceID() != null) {
                    /*--------------------------------------------------
                    *  getArchives() - For List of Archived Sessions
                    ---------------------------------------------------*/
                    appSyncApi.getArchives(((EKGapp) getApplication()).getUserID(),
                            new GraphQLCall.Callback<GetArchivesQuery.Data>() {
                                @Override
                                public void onResponse(@Nonnull Response<GetArchivesQuery.Data> response) {
                                    // New Session data received from subscription
                                    if (response.data() == null) {
                                        Log.i(TAG, "Archive Response No Data.");
                                    } else {
                                        Log.i(TAG, "Archive Response " + response.data().toString());
                                    }

                                    List<Archive> archives = appSyncApi.mapArchive(response.data());

                                    if (! archives.isEmpty()) {
                                        for (int i=0; i < 30; i++){
                                            Archive archive = archives.get(i);
                                            // Output list as "archiveId: datetime"
                                            archiveList.add(archive);
                                            Log.v(TAG, "Added " + archive.getTimeStamp() + " to archive list");
                                        }
                                    }

                                    // Go back to UI thread and set Recycler adapter
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            // Setup List & Adapter
                                            mAdapter = new HistoryAdapter(archiveList);
                                            recyclerView.setAdapter(mAdapter);
                                        }// End method
                                    });// End closure

                                } // onResponse() [getArchives]

                                // ------ Fails to connect to AWS ------
                                @Override
                                public void onFailure(@Nonnull ApolloException e) {
                                    // Error: AWS Connection Failure
                                    Log.e(TAG,  e.getMessage());

                                    // Go back to UI thread and set Recycler adapter
                                    runOnUiThread(new Runnable() {
                                        @Override
                                        public void run() {
                                            // Setup List & Adapter
                                            mAdapter = new HistoryAdapter(archiveList);
                                            recyclerView.setAdapter(mAdapter);
                                        }// End method
                                    });// End closure
                                } // onFailure() [getArchives]
                            }); // getArchives()
                        } // if
                    }// End function

                    @Override
                    public void onFailure(@Nonnull ApolloException e) {
                        // Error: AWS Connection Failure
                        Log.e(TAG, e.getMessage());

                        // Go back to UI thread and set Recycler adapter
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                // Setup List & Adapter
                                mAdapter = new HistoryAdapter(archiveList);
                                recyclerView.setAdapter(mAdapter);
                            }// End method
                        });// End closure
                    } // onFailure() [getAccount]
                }); // getAccount()
    }// End setUpRecyclerView Method


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(item.getItemId() == android.R.id.home) {
            drawerLayout.openDrawer(Gravity.START);
            return true;
        }// End if statement


        return super.onOptionsItemSelected(item);
    }// End onOptionsItemSelected() Method

}// End History class
