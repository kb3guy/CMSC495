#!/usr/bin/python
#
# HTTP Implementation Reference: https://www.acmesystems.it/python_http
#
# Current ML model is based on: https://www.kaggle.com/coni57/model-from-arxiv-1805-00794/
#
# Inspiration for the beat detection using find_peaks was observed in multiple implementations,
# but the implementation contained in this file is unique from most since we are operating on
# normalized data and have a different range of sensible parameters.
#

import time
import json
# For useful debugging output
import traceback

# Imports for the HTTP service implementation
from http.server import BaseHTTPRequestHandler, HTTPServer
import cgi

# For now, so we can simplify design we will use the threading-only
# version of the multiprocessing module.
from multiprocessing.dummy import Process
from concurrent.futures import ThreadPoolExecutor

# Math and data assistnace libraries
import numpy
import scipy.signal
import pandas

# These are used for interacting with AWS
import boto3
from boto3.dynamodb.conditions import Key, Attr
from botocore.exceptions import ClientError

# Necessary to import the beat classification model.
from keras.models import load_model

# Global thread pool for processing the data
_thread_pool = ThreadPoolExecutor(max_workers=5)

# Global tracking the state of the HTTP service
_started = False

# Global tracking the reference to the HTTP service
_server = None

# This is the input dimension of the temporary beat classifier
NORMALIZED_BEAT_TIME = 187

# This is the frequency of the temporary beat classifier.
TARGET_FREQ = 125

def _class_to_name(class_num):
    '''
    Translates a beat classifier classification number into a human readable
    value indicating the type of the beat.

    Parameters
    ----------
    class_num : int
        Machine learning classification value to look-up the name for.

    Returns
    -------
    A string describing the class name of the beat.

    Raises
    ------
    None    
    '''
    # for the five classification model
    xlat = { 0 : 'normal',
             1 : 'Supraventricular premature beat',
             2 : 'Premature ventricular contraction',
             3 : 'Fusion of ventricular and normal beat',
             4 : 'Unclassifiable beat' }
    return xlat[class_num]

class SessionProcessor(object):
    '''
    This class contains the methods and processes to prepare incoming ECG data for
    beat classification, execute the beat classifier on the data, and update the
    database with the beat classifications.
    
    Later extensions will attempt to detect types of heart rhythms that may be
    apparent in the heart rate data to detect certain conditions beyond individual
    beat classifications.
    '''
    
    @staticmethod
    def _resample(infreq, data, outfreq=TARGET_FREQ):
        '''
        Interpolates or supersamples (as necessary) to take the input data at the given
        frequency and convert it to a new sequence at the desired output frequency.
        
        Parameters
        ----------
        infreq : int
            Integer frequency of the input data in Hertz.
        data : arraylike
            Data sequence to resample.
        outfreq : int
            Integer frequency desired for the output data.

        Returns
        -------
        A new resampled sequence representing the input data.

        Raises
        ------
        None    
        '''
        print('_resample')
        in_time = len(data)/infreq
        out_samples = in_time * TARGET_FREQ
        if len(data) <= 1: 
            return []
        return numpy.interp(numpy.linspace(0, out_samples, num=out_samples),
                            numpy.linspace(0, len(data), num=len(data)),
                            data,
                            left=0,
                            right=0)

    @staticmethod
    def _normalize(data):
        '''
        Simple 1-d matrix normalization. Scales the input data into a range of [0, 1].
        
        Parameters
        ----------
        data : arraylike
            Data sequence to normalize.

        Returns
        -------
        A new sequence that contains the normalized input data.

        Raises
        ------
        None    
        '''
        print('_normalize')
        mn = numpy.amin(data)
        mx = numpy.amax(data)
        data = (data - mn) / (mx-mn)
        return data

    def _get_record_from_dynamo(self):
        '''
        Parameters
        ----------
        sessionId : str
            Unique identifier for the record to extract from the database.

        Returns
        -------
        The record information. The record will essentially be a Python dictionary,
        although it might arrive as a JSON object first.

        Raises
        ------
        None        
        '''
        print('_get_record_from_dynamo')
        record = None
        try:

            response = self.session_table.get_item(Key={'sessionId' : self.sessionId, 'deviceId' : self.deviceId})
            record = response['Item']
        except Exception as e:
            traceback.print_exc(e)
            
        return record
    
    def _update_record(self):
        '''
        Refreshes the session information from the database.
        
        Parameters
        ----------
        recordid : str
            Unique identifier for the record to read and process from the database.

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('_update_record')
        updated_rec = self._get_record_from_dynamo()
        if None is not updated_rec:
            self.record_ref = updated_rec
            # Need to cast to float for some calculations that do not support the Decimal type.
            self.record_ref['frequency'] = float(self.record_ref['frequency'])
            
    def __init__(self, sessionId, deviceId, sleep_callback=None):
        '''
        Initializes the instance, and prepares to process the record datas as they arrive.
        
        Parameters
        ----------
        recordid : str
            Unique identifier for the record to read and process from the database.

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('__init__')
        self.data_index = 0
        self.norm_index = 0
        self.beat_index = 0
        self.data_buffer = []
        self.norm_buffer = []
        self.beat_queue = []
        self.classified = []
        # maximum number of seconds to try to process the data
        # 60 seconds * 30 = 1800 ==> 30 minutes
        self.processing_time = 1800
        # utility in case something needs a per-hook chunk
        self.sleep_callback = sleep_callback
        dynamodb_resource = boto3.resource('dynamodb', region_name='us-east-1')
        self.session_table = dynamodb_resource.Table('Session')
        self.lam_client = boto3.client('lambda', region_name='us-east-1')
        # TODO: In the real world, it would probably be wise to lock the record
        #       so some other thread couldn't pick it up due to a duplicate submission.
        #       This would just be a simple atomic swap I believe. Hopefully DynamoDb
        #       supports that type of operation.
        self.sessionId = sessionId
        self.deviceId = deviceId
        self.record_ref = self._get_record_from_dynamo()
        self.model = load_model('model_class5.h5')

    def _update_data_buffer(self):
        '''
        Appends any updated data from the database record to the raw data queue.
        Tracks the input and continuously normalizes the new data in a 5
        second chunks, then resamples it to the target frequency.
        
        Parameters
        ----------
        None

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('_update_data_buffer')
        # update all available data
        chunk_size = int((5 * self.record_ref['frequency']))
        self._update_record()
        new_data = self.record_ref['data'][self.data_index:]
        self.data_index += len(new_data)
        self.data_buffer.extend(new_data)
        
        # create normalized 5 second chunks. We don't normalize all available data at once
        # because sometimes the voltages drift around. This will keep things relatively
        # correct.
        while (len(self.data_buffer) - self.norm_index) > chunk_size:
            data_to_norm = numpy.array(self.data_buffer[self.norm_index:self.norm_index + chunk_size], dtype=numpy.float32)
            normed_data = SessionProcessor._normalize(data_to_norm)
            resamp_data = SessionProcessor._resample(self.record_ref['frequency'], normed_data)
            self.norm_buffer.extend(resamp_data)
            self.norm_index += chunk_size
        
        # special case, the session is over, we can normalize any remaining data
        if not self.record_ref['status'] == 'active':
            # since the remaining data might not be a 5 second window, we might have to borrow
            # from the last chunk to get reasonable data values out of normalization
            borrow_amount = chunk_size - (len(self.data_buffer) - self.norm_index)
            data_to_norm = numpy.array(self.data_buffer[self.norm_index - borrow_amount:], dtype=numpy.float32)
            normed_data = SessionProcessor._normalize(data_to_norm)
            # but we only need to add the data that wasn't borrowed
            normed_data = normed_data[borrow_amount:]
            resamp_data = SessionProcessor._resample(self.record_ref['frequency'], normed_data)
            self.norm_buffer.extend(resamp_data)
            # this is kind of superfluous, but it is a useful artifact for testing
            # to see if the norm_index has actually reached the end of the data
            self.norm_index += len(normed_data)            
    
    def _update_beat_queue(self):
        '''
        TODO: Applies a one-dimensional convolutional filter to locate the center point
        of a beat, and create a "beat" and add it to the list of beats to process.
        In addition to the convolutional filter, it is also checked to make sure
        that for the sample, the center fifth contains the highest amplitude in
        the entire sample.
        
        Current implementation uses a find-peaks approach, which works very well on normalized data.
        
        Parameters
        ----------
        None

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        # even the most elite athletes don't have resting heart rates lower than
        # 30bpm, so a two second chunk size for beat detection should have at least
        # one beat in it
        print('_update_beat_queue')
        peaks, _ = scipy.signal.find_peaks(
            self.norm_buffer[self.beat_index:len(self.norm_buffer)-NORMALIZED_BEAT_TIME*2],
            height=0.95,
            distance=30)
        for peak in peaks:
            start = self.beat_index + int(peak-NORMALIZED_BEAT_TIME/2)
            stop = self.beat_index + int(peak+NORMALIZED_BEAT_TIME/2)
            if start < 0:
                start = 0
                stop = NORMALIZED_BEAT_TIME
            if stop > len(self.norm_buffer):
                start = len(self.norm_buffer) - NORMALIZED_BEAT_TIME
                stop = len(self.norm_buffer)
            data = self.norm_buffer[start:stop]
            self.beat_queue.append({'start': self.beat_index + start,
                                    'stop' : self.beat_index + stop,
                                    'norm_data' : data})
        self.beat_index = len(self.norm_buffer)
        
    def _classify(self, data):
        '''
        '''
        print('_classify')
        result = self.model.predict(data, batch_size=1)
        return result
    
    def _classify_beats(self):
        '''
        Take all remaining queued beats, predict the beat type, and append it
        to the list of classified beats.
        
        Parameters
        ----------
        None

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('_classify_beats')
        beats_to_deque = []
        for beat in self.beat_queue:
            data = numpy.array(beat['norm_data']).reshape((1,187,1))
            beat_results = self._classify(data)
            norm_results = SessionProcessor._normalize(beat_results)
            beat['cond'] = []
            for r in norm_results[0]:
                if r > 0.25:
                    for x in range(0, 5):
                        if r == norm_results[0][x]:
                            beat['cond'].append({'name' : _class_to_name(x), 'confidence' : r})
            beats_to_deque.append(beat)
            
        for beat in beats_to_deque:
            # we need to reconvert the time indices back to their locations
            # in the original record by using the ratio of the input and
            # resampled frequency.
            beat['start'] = (beat['start'] * self.record_ref['frequency'])/TARGET_FREQ
            beat['stop'] = (beat['stop'] * self.record_ref['frequency'])/TARGET_FREQ
            # remove it from the list of unclassified beats, and
            self.beat_queue.remove(beat)
            # add it to the list of classified beats
            self.classified.append(beat)

    def _save_record(self):
        '''
        Update the session record in the database with the classified beat
        information.
        
        TODO: For efficiencies sake, we might be able to selectively update
        the list of beats, but for now we will just overwrite any existing
        data for the first cut of the implementation.
        
        
        Data format the lambda expects:
        {
            "arguments": {
                "sessionId" : string, 
                "deviceId" : string,
                "beats " : [{
                    start: int, 
                    stop: int, 
                    val: [float], 
                    conditions; [{
                        name: string, 
                        con: float
                    }]
                }]
            }
        }
        
        Parameters
        ----------
        None

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('_save_record')
        if 0 == len(self.classified):
            # nothing to write
            return
        
        LAMBDA_OK = 200
        xmitted_beats = []
        # pack up all the beats in the right format
        for beat in self.classified:
            session = { "arguments" : {"sessionId" : self.record_ref['sessionId'], "deviceId" : self.record_ref['deviceId'], "beats" : []}}
            # If we haven't associated the original data with this beat, do so here.
            # NOTE: start and stop indices are updated to match the index of the original data (vs. normalized).
            if 'value' not in beat.keys():
                beat['value'] = self.data_buffer[int(beat['start']):int(beat['stop'])]
            beat_info = {'conditions' : []}
            beat_info['start'] = int(beat['start'])
            beat_info['stop'] = int(beat['stop'])
            beat_info['val'] = list([float(i) for i in beat['value']])
            for cond in beat['cond']:
                beat_info['conditions'].append({'name' : str(cond['name']), 'conf' : float(cond['confidence'])})
            session['arguments']['beats'].append(beat_info)

            encoded_session = json.dumps(session)
            try:
                response = self.lam_client.invoke(
                    FunctionName='arn:aws:lambda:us-east-1:871036824499:function:writeBeat',
                    Payload=encoded_session,
                    InvocationType='RequestResponse')
                if LAMBDA_OK == response['StatusCode']:
                    # the classified beat was written out successfully, so it can be load
                    print('beat written out.')
                    xmitted_beats.append(beat)
                else:
                    # for some reason writing the last beat failed, show the error and
                    # exit out of the loop. Maybe it will work later.
                    print(response)
                    break
            except Exception as e:
                traceback.print_exc(e)
                print(encoded_session)
            time.sleep(1)
        for b in xmitted_beats:
            self.classified.remove(b)


    def handle_session(self):
        '''
        Processes the session, ingesting the raw data, classifying the beats,
        and updating the database with the results.
        
        Parameters
        ----------
        None

        Returns
        -------
        None

        Raises
        ------
        None
        '''
        print('_handle_session')
        start_time = time.time()
        current_time = time.time()
        while self.processing_time - (current_time - start_time) > 0:
            self._update_data_buffer()
            self._update_beat_queue()
            self._classify_beats()
            self._save_record()
            # wait two seconds for data to arrive, and update the processing time
            if None is not self.sleep_callback:
                self.sleep_callback()
            time.sleep(1)
            current_time = time.time()
            
            # if the session is over, try one more round of processing, then break out
            if not self.record_ref['status'] == 'active':
                self._update_data_buffer()
                self._update_beat_queue()
                self._classify_beats()
                self._save_record()
                break
                
def _run_session_handler(sessionId, deviceId):
    '''
    Simple thread function to kick off a processing instance.
    '''    
    sp = SessionProcessor(sessionId, deviceId)
    # terminates itself after the session is over or the maximum time is exceeded
    sp.handle_session()

class _webservice_handler(BaseHTTPRequestHandler):
    '''
    Web service request handler that queues record IDs to be processed from the configured
    database.
    '''
    def do_POST(self):
        '''
        Simple HTTP POST handler that looks for a form data field 'recordid' that contains the
        record that needs to be processed.
        '''
        global _processing_queue
        try:
            # get the form data from the HTTP request
            form = cgi.FieldStorage(
                fp=self.rfile, 
                headers=self.headers,
                environ={'REQUEST_METHOD':'POST',
                         'CONTENT_TYPE':self.headers['Content-Type'],})
            print(form)
            sessionId = form['sessionId'].value
            deviceId = form['deviceId'].value
            # and queue it for completion
            _thread_pool.submit(_run_session_handler, sessionId, deviceId)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(bytes('Submitted for processing.', 'utf-8'))
        except Exception as e:
            traceback.print_exc()
            self.send_error(501, 'Internal Error')

def _run_service(addr, port):
    '''
    Threading target function that launches the HTTPServer instance and attempts to serve
    requests until terminated (_server.serve_forever()). The module stop function causes
    the service itself to exit, which will allow serve_forever to terminate.
    
    Parameters
    ----------
    addr : str
        IP address string of the interface to listen on.
    port : int
        Network port to listen on. Integer between 1 and 65536
    
    Returns
    -------
    None
    
    Raises
    ------
    None
    '''
    global _server
    try:
        _server = HTTPServer((addr, port), _webservice_handler)
        _server.serve_forever()
    except Exception as e:
        print(e)

#
# System interfaces below here!
#
    
def start(addr='0.0.0.0', port=8080):
    '''
    Starts the HTTP service that accepts instructions to monitor and process a session. The service
    then starts up individual threads that handle the processing of the heart rate data and run it
    through the service.
    
    By default the service listens on all interfaces on port 8080. This can be adjusted as needed,
    but keep in mind ports lower than 1024 often require local administrator privileges. Furthermore,
    since the web service is not tested extensively, it is not safe to run this in a privileged context.
    
    Parameters
    ----------
    addr : str, optional
        IP address string of the interface to listen on. Default is 0.0.0.0
    port : int, optional
        Network port to listen on. Integer between 1 and 65536. Default is 8080.
    
    Returns
    -------
    None
    
    Raises
    ------
    None
    '''
    global _started
    global _proc_ref
    
    if not _started:
        _started = True
        _proc_ref = Process(target=_run_service, args=(addr, port))
        _proc_ref.start()
    return

def stop():
    '''
    Stops the HTTP web service. Note that this will not terminate all the threads the service started
    that may be processing heart rate data. These threads have a maximum run time of MAX_CAP_TIME minutes, so
    the longest a caller should wait after calling this function is that time.
    
    Parameters
    ----------
    None
    
    Returns
    -------
    None
    
    Raises
    ------
    None
    '''
    global _proc_ref
    global _term_sig
    global _started
    global _server
    if _server is not None:
        _server.shutdown()
        _proc_ref.join()
        _server = None
        _started = False
        _proc_ref = None
    return

# so the script can simply be run as a service.
if __name__== "__main__":
    try:
        start()
    except KeyboardInterrupt:
        print('Caught keyboard interrupt. Terminating service.')
        stop()


