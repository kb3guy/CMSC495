
def predict(ecg_data, freq=200, model_name='default'):
    return ([1,2,3,4], [(0, 0.95), (1,0.03), (2,0.01)])
